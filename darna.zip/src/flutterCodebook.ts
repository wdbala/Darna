/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface FlutterCodeFile {
  filename: string;
  language: string;
  description: string;
  code: string;
}

export const flutterCodeook: FlutterCodeFile[] = [
  {
    filename: 'theme_style.dart',
    language: 'dart',
    description: 'Material 3 Color Scheme & Sudanese-Inspired Styling Theme Configuration',
    code: `import 'package:flutter/material.dart';

class DarnaTheme {
  // Sudanese patriotic & cultural color constants
  static const Color primaryGreen = Color(0xFF007A4D);
  static const Color secondaryGold = Color(0xFFD4A017);
  static const Color backgroundWhite = Color(0xFFFFFFFF);
  static const Color darkBackground = Color(0xFF121212);
  static const Color deepText = Color(0xFF2D2D2D);
  static const Color alertRed = Color(0xFFD22630);

  // Generates complete Light Theme data
  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryGreen,
        primary: primaryGreen,
        secondary: secondaryGold,
        error: alertRed,
        brightness: Brightness.light,
      ),
      fontFamily: 'Cairo', // Custom Arabic-Supporting elegant font
      scaffoldBackgroundColor: backgroundWhite,
      appBarTheme: const AppBarTheme(
        backgroundColor: primaryGreen,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      cardTheme: CardTheme(
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  // Generates complete Dark Theme data
  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryGreen,
        primary: primaryGreen,
        secondary: secondaryGold,
        error: alertRed,
        brightness: Brightness.dark,
      ),
      fontFamily: 'Cairo',
      scaffoldBackgroundColor: darkBackground,
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF1E1E1E),
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
    );
  }
}`
  },
  {
    filename: 'firebase_auth_service.dart',
    language: 'dart',
    description: 'Firebase Authentication service managing Register, Login, and Profile updates in Firestore',
    code: `import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class DarnaAuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Stream of authorized user state changes
  Stream<User?> get userStateStream => _auth.authStateChanges();

  // Sign In with email & pattern
  Future<UserCredential?> signIn({required String email, required String password}) async {
    try {
      return await _auth.signInWithEmailAndPassword(email: email, password: password);
    } on FirebaseAuthException catch (e) {
      print("Auth Error: \${e.message}");
      rethrow;
    }
  }

  // Sign Up with profile data synced into Firestore
  Future<void> signUp({
    required String email,
    required String password,
    required String name,
    required String phone,
    required String city,
    required String country,
  }) async {
    try {
      UserCredential credential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      User? user = credential.user;
      if (user != null) {
        // Hydrate FireStore user record
        await _db.collection('users').doc(user.uid).set({
          'id': user.uid,
          'name': name,
          'email': email,
          'phone': phone,
          'city': city,
          'country': country,
          'bio': 'Proud member of the Darna Sudanese Global Community.',
          'avatar': '🇸🇩',
          'createdAt': FieldValue.serverTimestamp(),
        });
      }
    } catch (e) {
      print("Registration Error: \$e");
      rethrow;
    }
  }

  // Stream user custom profile attributes from Firestore
  Stream<DocumentSnapshot> streamUserProfile(String uid) {
    return _db.collection('users').doc(uid).snapshots();
  }

  // Sign Out
  Future<void> signOut() async {
    await _auth.signOut();
  }
}`
  },
  {
    filename: 'community_feed.dart',
    language: 'dart',
    description: 'Sudanese Diaspora Feed using StreamBuilder to display posts with comments from Firestore',
    code: `import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class CommunityFeedScreen extends StatefulWidget {
  const CommunityFeedScreen({Key? key}) : super(key: key);

  @override
  State<CommunityFeedScreen> createState() => _CommunityFeedScreenState();
}

class _CommunityFeedScreenState extends State<CommunityFeedScreen> {
  final TextEditingController _postController = TextEditingController();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _currentUid = FirebaseAuth.instance.currentUser?.uid ?? 'guest';

  String _selectedCategory = 'General';

  void _publishPost() async {
    if (_postController.text.trim().isEmpty) return;

    await _firestore.collection('feed').add({
      'userId': _currentUid,
      'userName': FirebaseAuth.instance.currentUser?.displayName ?? 'Anonymous Sudanese',
      'userAvatar': '🇸🇩',
      'content': _postController.text.trim(),
      'category': _selectedCategory,
      'datetime': DateTime.now().toIso8601String(),
      'likes': 0,
      'commentCount': 0,
    });

    _postController.clear();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('منشورك رائع ومفتاح تواصل جديد! تم النشر')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('دارنا - صالة التواصل')),
      body: Column(
        children: [
          // Posting card
          Card(
            margin: const EdgeInsets.all(8.0),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                children: [
                  TextField(
                    controller: _postController,
                    maxLines: 3,
                    decoration: const InputDecoration(
                      hintText: 'ماذا يدور في ذهنك لمشاركتها مع الجالية؟',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      DropdownButton<String>(
                        value: _selectedCategory,
                        items: ['General', 'News', 'Cultural', 'Urgent'].map((cat) {
                          return DropdownMenuItem(value: cat, child: Text(cat));
                        }).toList(),
                        onChanged: (val) {
                          if (val != null) setState(() => _selectedCategory = val);
                        },
                      ),
                      ElevatedButton(
                        onPressed: _publishPost,
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF007A4D)),
                        child: const Text('نشر موضوع'),
                      )
                    ],
                  )
                ],
              ),
            ),
          ),
          
          // Stream List
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _firestore
                  .collection('feed')
                  .orderBy('datetime', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                
                final docs = snapshot.data!.docs;
                return ListView.builder(
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final post = docs[index].data() as Map<String, dynamic>;
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      child: ListTile(
                        leading: CircleAvatar(child: Text(post['userAvatar'] ?? '👤')),
                        title: Text(post['userName'] ?? ''),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 5),
                            Text(post['content'] ?? ''),
                            const SizedBox(height: 5),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text('Category: \${post['category']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                                Text('Likes: \${post['likes']}'),
                              ],
                            )
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          )
        ],
      ),
    );
  }
}`
  },
  {
    filename: 'maps_service_directory.dart',
    language: 'dart',
    description: 'Sudanese Service Directory using Google Maps tracking coordinates of diaspora centers',
    code: `import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class MapsDirectoryScreen extends StatefulWidget {
  const MapsDirectoryScreen({Key? key}) : super(key: key);

  @override
  State<MapsDirectoryScreen> createState() => _MapsDirectoryScreenState();
}

class _MapsDirectoryScreenState extends State<MapsDirectoryScreen> {
  late GoogleMapController _mapController;
  final Set<Marker> _markers = {};
  
  // Riyadh focus default coord
  static const LatLng _initialCenter = LatLng(24.7136, 46.6753);

  @override
  void initState() {
    super.initState();
    _loadDirectoryPins();
  }

  void _loadDirectoryPins() async {
    // Dynamic query from firestore
    final services = await FirebaseFirestore.instance.collection('services').get();
    
    setState(() {
      for (var doc in services.docs) {
        final data = doc.data();
        _markers.add(
          Marker(
            markerId: MarkerId(doc.id),
            position: LatLng(data['lat'], data['lng']),
            infoWindow: InfoWindow(
              title: data['name'],
              snippet: '\${data['category']} - \${data['phone']}',
              onTap: () => _displayDetailSheet(context, data),
            ),
            icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
          ),
        );
      }
    });
  }

  void _displayDetailSheet(BuildContext ctx, Map<String, dynamic> data) {
    showModalBottomSheet(
      context: ctx,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(data['name'], style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: const Color(0xFF007A4D))),
              const SizedBox(height: 8),
              Chip(label: Text(data['category'])),
              const SizedBox(height: 10),
              Text(data['description']),
              const SizedBox(height: 15),
              Row(
                children: [
                  const Icon(Icons.phone, color: Colors.green),
                  const SizedBox(width: 8),
                  Text(data['phone']),
                ],
              ),
              const SizedBox(height: 10),
              if (data['website'] != null) Text('Website: \${data['website']}', style: const TextStyle(color: Colors.blue)),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('دليل الخدمات والتجمعات')),
      body: GoogleMap(
        initialCameraPosition: const CameraPosition(target: _initialCenter, zoom: 6),
        markers: _markers,
        onMapCreated: (controller) => _mapController = controller,
      ),
    );
  }
}`
  },
  {
    filename: 'derna_messaging_service.dart',
    language: 'dart',
    description: 'Darna Mobile Chat Core showing streaming private message channels',
    code: `import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class DarnaMessagingService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final String _currentUid = FirebaseAuth.instance.currentUser?.uid ?? 'guest';

  // Get active streams between me and specific user
  Stream<QuerySnapshot> getMessageStream(String peerId) {
    List<String> ids = [_currentUid, peerId];
    ids.sort();
    String chatRoomId = ids.join("_");

    return _firestore
        .collection('chat_rooms')
        .doc(chatRoomId)
        .collection('messages')
        .orderBy('timestamp', descending: true)
        .snapshots();
  }

  // Send message safely to firebase
  Future<void> sendMessage(String recipientId, String content) async {
    List<String> ids = [_currentUid, recipientId];
    ids.sort();
    String chatRoomId = ids.join("_");

    final timestamp = Timestamp.now();

    // Create the message document
    await _firestore
        .collection('chat_rooms')
        .doc(chatRoomId)
        .collection('messages')
        .add({
      'senderId': _currentUid,
      'receiverId': recipientId,
      'text': content,
      'timestamp': timestamp,
    });

    // Update parent thread metadata for fast sidebar fetching
    await _firestore.collection('chat_rooms').doc(chatRoomId).set({
      'lastMessage': content,
      'lastUpdated': timestamp,
      'participants': ids,
    }, SetOptions(merge: true));
  }
}`
  }
];
