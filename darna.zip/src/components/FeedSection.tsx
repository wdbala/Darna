/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Heart, MessageSquare, Plus, Search, Send, ShieldAlert, Sparkles, User } from 'lucide-react';
import { FeedPost } from '../types';

interface FeedSectionProps {
  feedPosts: FeedPost[];
  currentUserAvatar: string;
  currentUserName: string;
  onLikePost: (postId: string) => void;
  onAddComment: (postId: string, commentText: string) => void;
  onPublishPost: (content: string, category: 'General' | 'News' | 'Cultural' | 'Urgent') => void;
  language: 'en' | 'ar';
}

export default function FeedSection({
  feedPosts,
  currentUserAvatar,
  currentUserName,
  onLikePost,
  onAddComment,
  onPublishPost,
  language,
}: FeedSectionProps) {
  const [newPostText, setNewPostText] = useState('');
  const [newPostCategory, setNewPostCategory] = useState<'General' | 'News' | 'Cultural' | 'Urgent'>('General');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('All');
  const [expandedCommentsPostId, setExpandedCommentsPostId] = useState<string | null>(null);
  const [commentInputs, setCommentInputs] = useState<{ [postId: string]: string }>({});

  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostText.trim()) return;
    onPublishPost(newPostText.trim(), newPostCategory);
    setNewPostText('');
  };

  const handleCommentSubmit = (postId: string) => {
    const text = commentInputs[postId] || '';
    if (!text.trim()) return;
    onAddComment(postId, text.trim());
    setCommentInputs((prev) => ({ ...prev, [postId]: '' }));
  };

  // Filter logic
  const filteredPosts = feedPosts.filter((post) => {
    const matchesSearch =
      post.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.userName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategoryFilter === 'All' || post.category === activeCategoryFilter;
    return matchesSearch && matchesCategory;
  });

  const isRtl = language === 'ar';

  const categoryLabels = {
    All: isRtl ? 'الكل' : 'All',
    General: isRtl ? 'نقاش عام' : 'General Discussion',
    News: isRtl ? 'أخبار المغتربين' : 'News',
    Cultural: isRtl ? 'ثرات وثقافة' : 'Heritage & Culture',
    Urgent: isRtl ? 'مساعدات طارئة 🚨' : 'Urgent Help 🚨',
  };

  const categoryEmojis = {
    General: '💬',
    News: '📰',
    Cultural: '🇸🇩',
    Urgent: '🆘',
  };

  return (
    <div className="space-y-6 animate-fade-in font-cairo">
      {/* Search & Statistics summary */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:max-w-md">
          <Search className="absolute top-2.5 right-3 w-4 h-4 text-slate-400 dark:text-zinc-500" />
          <input
            type="text"
            placeholder={isRtl ? 'البحث في منشورات الجالية...' : 'Search community posts...'}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full py-2 bg-white dark:bg-zinc-950 text-slate-800 dark:text-zinc-150 border border-slate-200 dark:border-zinc-800 rounded-lg text-xs outline-none focus:border-sudan-green transition-all ${
              isRtl ? 'pr-3 pl-10 text-right' : 'pl-3 pr-10 text-left'
            }`}
          />
        </div>

        {/* Categories filters */}
        <div className="flex gap-1.5 overflow-x-auto w-full md:w-auto pb-1.5 md:pb-0 scrollbar-none">
          {['All', 'General', 'News', 'Cultural', 'Urgent'].map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategoryFilter(cat)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                activeCategoryFilter === cat
                  ? 'bg-sudan-green text-white shadow-sm'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50 dark:bg-zinc-950 dark:text-slate-350 dark:border-zinc-800 dark:hover:bg-zinc-900'
              }`}
            >
              {categoryLabels[cat as keyof typeof categoryLabels]}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        {/* Post Form column */}
        <div className="lg:col-span-1 bg-white dark:bg-zinc-950 p-4 rounded-xl border border-slate-200 dark:border-zinc-850 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 dark:border-zinc-900 pb-2">
            <span className="p-1 bg-emerald-100 dark:bg-emerald-950/40 rounded text-sudan-green">
              <Plus className="w-4 h-4" />
            </span>
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 font-cairo">
              {isRtl ? 'أنشئ منشوراً جديداً' : 'Publish Community Status'}
            </h3>
          </div>

          <form onSubmit={handlePostSubmit} className="space-y-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                {isRtl ? 'تصنيف المنشور' : 'Post Category'}
              </label>
              <select
                value={newPostCategory}
                onChange={(e) => setNewPostCategory(e.target.value as any)}
                className="w-full p-2 bg-slate-50 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-lg text-xs text-slate-700 dark:text-slate-300 outline-none focus:border-sudan-green"
              >
                <option value="General">💬 {isRtl ? 'نقاش عام' : 'General Discussion'}</option>
                <option value="News">📰 {isRtl ? 'أخبار المغتربين' : 'News & Announcements'}</option>
                <option value="Cultural">🇸🇩 {isRtl ? 'شأن وثقافة سودانية' : 'Heritage & Culture'}</option>
                <option value="Urgent">🆘 {isRtl ? 'طلب مساعدة طارئة' : 'Urgent Diaspora Support'}</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-1 font-cairo">
                {isRtl ? 'محتوى المنشور' : 'Post Content'}
              </label>
              <textarea
                placeholder={
                  isRtl
                    ? 'اكتب شيئاً لأبناء الجالية... (مثل: اقتراح لقاء، إرشادات، طلب توجيه)'
                    : 'Share links, resources, support announcements or questions...'
                }
                rows={4}
                value={newPostText}
                onChange={(e) => setNewPostText(e.target.value)}
                maxLength={450}
                className={`w-full p-2.5 bg-slate-50 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-lg text-xs leading-relaxed outline-none focus:border-sudan-green text-slate-800 dark:text-slate-200 ${
                  isRtl ? 'text-right' : 'text-left'
                }`}
              ></textarea>
              <div className="text-[10px] text-slate-400 text-right">
                {newPostText.length}/450
              </div>
            </div>

            <button
              type="submit"
              disabled={!newPostText.trim()}
              className="w-full bg-sudan-green hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-xs py-2 px-4 rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isRtl ? 'نشر الآن في الصالة' : 'Publish to Feed'}</span>
            </button>
          </form>

          {/* Guidelines box */}
          <div className="bg-emerald-50/50 dark:bg-zinc-900/50 p-3 rounded-lg border border-sudan-green/10 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400 space-y-1">
            <h4 className="font-bold text-sudan-green flex items-center gap-1 font-cairo text-xs mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              {isRtl ? 'شعارنا الدائم مودة وتكافل' : 'Diaspora Support Rules'}
            </h4>
            <p>
              {isRtl
                ? 'دارنا تهدف لجمع شمل السودانيين بالخارج. يُرجى صون الاحترام، المساعدة البنّاءة وصون العلاقات الوطنية الطيبة.'
                : 'All posts are synchronized live. Keep posts supportive of regional diaspora challenges, job leads, or cultural events.'}
            </p>
          </div>
        </div>

        {/* Feed Posts column */}
        <div className="lg:col-span-2 space-y-4">
          {filteredPosts.length === 0 ? (
            <div className="bg-white dark:bg-zinc-950 p-8 rounded-xl border border-slate-250 dark:border-zinc-800 text-center space-y-2">
              <span className="text-3xl">📭</span>
              <h4 className="text-sm font-bold text-slate-700 dark:text-slate-350">
                {isRtl ? 'لم نعثر على أي منشورات تطابق بحثك' : 'No feed threads found'}
              </h4>
              <p className="text-xs text-slate-400">
                {isRtl ? 'كن أنت البادئ واكتب أول منشور في هذا التصنيف!' : 'Be the pioneer by publishing a new thread right now!'}
              </p>
            </div>
          ) : (
            filteredPosts.map((post) => {
              const categoryDetails = getCategoryDetails(post.category);
              const isCommentsExpanded = expandedCommentsPostId === post.id;

              return (
                <div
                  key={post.id}
                  className={`bg-white dark:bg-zinc-950 p-4 rounded-xl border border-slate-200 dark:border-zinc-850 shadow-sm transition-all relative overflow-hidden ${
                    post.category === 'Urgent' ? 'ring-1 ring-sudan-red/10 border-sudan-red/30' : ''
                  }`}
                >
                  {/* Category Accent strip */}
                  <div
                    className={`absolute top-0 inset-x-0 h-1 ${
                      post.category === 'Urgent'
                        ? 'bg-sudan-red'
                        : post.category === 'News'
                        ? 'bg-blue-500'
                        : post.category === 'Cultural'
                        ? 'bg-sudan-gold'
                        : 'bg-sudan-green'
                    }`}
                  ></div>

                  {/* Top Bar author layout */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-full bg-slate-100 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 flex items-center justify-center text-lg select-none">
                        {post.userAvatar}
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100">
                          {post.userName}
                        </h4>
                        <span className="text-[10px] text-slate-450 dark:text-slate-500">
                          {new Date(post.datetime).toLocaleDateString(language === 'ar' ? 'ar-SD' : 'en-US', {
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                    </div>

                    {/* Category Label */}
                    <span
                      className={`text-[9.5px] font-bold px-2 py-0.5 rounded flex items-center gap-1 uppercase ${categoryDetails.classes}`}
                    >
                      <span>{categoryEmojis[post.category]}</span>
                      <span>{language === 'ar' ? categoryLabels[post.category] : post.category}</span>
                    </span>
                  </div>

                  {/* Body Text */}
                  <p
                    className={`text-xs text-slate-700 dark:text-slate-300 mt-3 whitespace-pre-wrap leading-relaxed ${
                      isRtl ? 'text-right' : 'text-left'
                    }`}
                  >
                    {post.content}
                  </p>

                  {/* Quick Action bar (likes and comments toggle) */}
                  <div className="flex items-center gap-6 mt-4 pt-3 border-t border-slate-100 dark:border-zinc-900 text-xs">
                    <button
                      onClick={() => onLikePost(post.id)}
                      className={`flex items-center gap-1.5 font-semibold cursor-pointer select-none transition-transform active:scale-95 ${
                        post.likedByMe
                          ? 'text-sudan-red'
                          : 'text-slate-500 hover:text-sudan-red dark:text-slate-450'
                      }`}
                    >
                      <Heart className={`w-4 h-4 ${post.likedByMe ? 'fill-current' : ''}`} />
                      <span>{post.likes}</span>
                    </button>

                    <button
                      onClick={() =>
                        setExpandedCommentsPostId(isCommentsExpanded ? null : post.id)
                      }
                      className="flex items-center gap-1.5 font-semibold text-slate-500 hover:text-sudan-green dark:text-slate-450 cursor-pointer"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>{post.comments.length}</span>
                      <span className="text-[10px] font-normal text-slate-400">
                        ({isCommentsExpanded ? (isRtl ? 'إخفاء التعليقات' : 'hide') : (isRtl ? 'عرض التعليقات' : 'show')})
                      </span>
                    </button>
                  </div>

                  {/* Comments section (Collapsible) */}
                  {isCommentsExpanded && (
                    <div className="mt-4 pt-4 border-t border-slate-100 dark:border-zinc-900 bg-slate-50 dark:bg-zinc-900/60 -mx-4 -mb-4 p-4 rounded-b-xl space-y-4">
                      <div className="space-y-3">
                        {post.comments.length === 0 ? (
                          <div className="text-center text-[11px] text-slate-450 dark:text-slate-500 py-1">
                            {isRtl ? 'لا توجد تعليقات بعد. اكتب أول تعليق تشجيعاً للموضوع!' : 'No comments yet. Write the first response!'}
                          </div>
                        ) : (
                          post.comments.map((comment, cIdx) => (
                            <div key={cIdx} className="flex gap-2 items-start text-xs rounded p-2 bg-white dark:bg-zinc-950 border border-slate-100 dark:border-zinc-900 animate-fade-in">
                              <span className="text-sm rounded-full bg-slate-50 p-1">{comment.userAvatar}</span>
                              <div className="flex-1">
                                <div className="flex justify-between items-center bg-slate-50/20 rounded p-1">
                                  <span className="font-bold text-slate-700 dark:text-slate-350">{comment.userName}</span>
                                  <span className="text-[10px] text-slate-400">
                                    {new Date(comment.datetime).toLocaleDateString(language === 'ar' ? 'ar' : 'en', {
                                      hour: '2-digit',
                                      minute: '2-digit',
                                    })}
                                  </span>
                                </div>
                                <p className="text-slate-600 dark:text-slate-300 mt-1 leading-normal pl-1">
                                  {comment.text}
                                </p>
                              </div>
                            </div>
                          ))
                        )}
                      </div>

                      {/* Comment Input form */}
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder={isRtl ? 'اكتب تعليقك...' : 'Write comment response...'}
                          value={commentInputs[post.id] || ''}
                          onChange={(e) =>
                            setCommentInputs((prev) => ({ ...prev, [post.id]: e.target.value }))
                          }
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleCommentSubmit(post.id);
                          }}
                          className={`flex-1 p-2 bg-white dark:bg-zinc-950 text-slate-850 dark:text-slate-150 border border-slate-200 dark:border-zinc-800 rounded-lg text-xs outline-none focus:border-sudan-green ${
                            isRtl ? 'text-right' : 'text-left'
                          }`}
                        />
                        <button
                          onClick={() => handleCommentSubmit(post.id)}
                          className="bg-sudan-green hover:bg-emerald-800 text-white rounded-lg px-3 py-2 flex items-center justify-center transition-all cursor-pointer"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}

function getCategoryDetails(cat: string) {
  switch (cat) {
    case 'Urgent':
      return {
        classes: 'bg-red-50 text-sudan-red border border-red-200 dark:bg-red-950/25 dark:border-red-900/40',
      };
    case 'News':
      return {
        classes: 'bg-blue-50 text-blue-700 border border-blue-200 dark:bg-blue-950/25 dark:border-blue-900/40',
      };
    case 'Cultural':
      return {
        classes: 'bg-amber-50 text-[#9E730B] border border-amber-200 dark:bg-amber-950/25 dark:border-amber-900/40',
      };
    default:
      return {
        classes: 'bg-emerald-50 text-sudan-green border border-emerald-200 dark:bg-zinc-900 dark:border-zinc-800',
      };
  }
}
