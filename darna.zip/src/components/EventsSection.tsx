/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Calendar, User2, Plus, Users, MapPin, Send, Check } from 'lucide-react';
import { CommunityEvent } from '../types';

interface EventsSectionProps {
  events: CommunityEvent[];
  onRsvp: (eventId: string) => void;
  onAddEvent: (newEvent: Omit<CommunityEvent, 'id' | 'rsvps'>) => void;
  language: 'en' | 'ar';
}

export default function EventsSection({ events, onRsvp, onAddEvent, language }: EventsSectionProps) {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [organizer, setOrganizer] = useState('');
  const [datetime, setDatetime] = useState('');
  const [location, setLocation] = useState('');
  const [category, setCategory] = useState<'Religious' | 'Cultural' | 'Charity' | 'Social' | 'Virtual'>('Social');
  const [description, setDescription] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !organizer || !datetime || !location || !description) return;
    onAddEvent({
      title,
      organizer,
      datetime,
      location,
      category,
      description,
    });
    // Reset Form
    setTitle('');
    setOrganizer('');
    setDatetime('');
    setLocation('');
    setDescription('');
    setIsFormOpen(false);
  };

  const isRtl = language === 'ar';

  const categoryLabels = {
    Religious: isRtl ? 'شعائر دينية (أعياد وغيرها)' : 'Religious Space',
    Cultural: isRtl ? 'محافل تراثية وثنائية' : 'Heritage Showcase',
    Charity: isRtl ? 'حملة تبرعات وإيواء جالية' : 'Charitable Support 🚨',
    Social: isRtl ? 'شواء ولقاء عائلي' : 'Social & Picnic Meetup',
    Virtual: isRtl ? 'ندوة حوارية عبر الإنترنت' : 'Webinar / Video Forum',
  };

  return (
    <div className="space-y-6 animate-fade-in font-cairo">
      {/* Header and Add button */}
      <div className="flex gap-4 items-center justify-between border-b border-slate-100 dark:border-zinc-900 pb-3">
        <div>
          <h3 className="text-base font-bold text-slate-800 dark:text-slate-100 font-cairo">
            {isRtl ? 'صالة المناسبات والفعاليات السودانية' : 'Darna Active Events Platform'}
          </h3>
          <p className="text-xs text-slate-450 dark:text-slate-400">
            {isRtl
              ? 'مساحة لتنظيم المناسبات الاجتماعية، تجمعات الشواء، حملات دعم المرضى والتعلم.'
              : 'Add, explore, and reserve seating for regional Sudanese activities worldwide.'}
          </p>
        </div>

        <button
          onClick={() => setIsFormOpen(!isFormOpen)}
          className="bg-sudan-green hover:bg-emerald-800 text-white font-bold text-xs px-4 py-2 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer shadow-sm shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>{isFormOpen ? (isRtl ? 'إغلاق النموذج' : 'Close Form') : (isRtl ? 'تنظيم فعالية جديدة 🇸🇩' : 'Organize Event')}</span>
        </button>
      </div>

      {/* Organizer Form Collapse */}
      {isFormOpen && (
        <form onSubmit={handleSubmit} className="bg-slate-50 dark:bg-zinc-900/60 p-5 rounded-xl border border-slate-200 dark:border-zinc-800 animate-slide-down space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1">{isRtl ? 'اسم الفعالية / المناسبة' : 'Event Title'}</label>
              <input
                type="text"
                required
                placeholder={isRtl ? 'مثال: ملتقى عائلات كندا السنوي، حفل تكريم الطلاب' : 'e.g. Sudanese Eid Mubarak Reunion'}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-805 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1">{isRtl ? 'الجهة المنظمة / الراعية' : 'Organizing Body'}</label>
              <input
                type="text"
                required
                placeholder={isRtl ? 'مثال: جمعية الأطباء السودانيين بالخليج' : 'e.g. Dallas Sudanese Alliance'}
                value={organizer}
                onChange={(e) => setOrganizer(e.target.value)}
                className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-850 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1">{isRtl ? 'تاريخ ووقت المناسبة' : 'Date and Time'}</label>
              <input
                type="datetime-local"
                required
                value={datetime}
                onChange={(e) => setDatetime(e.target.value)}
                className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-850 text-slate-850 dark:text-slate-100 rounded text-xs outline-none focus:border-sudan-green"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1">{isRtl ? 'تصنيف المناسبة' : 'Category Profile'}</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-850 text-slate-700 dark:text-slate-300 rounded text-xs outline-none focus:border-sudan-green"
              >
                <option value="Social">{isRtl ? 'اجتماعي وعائلي' : 'Social & Picnic'}</option>
                <option value="Cultural">{isRtl ? 'تراثي وفني' : 'Cultural Heritage'}</option>
                <option value="Charity">{isRtl ? 'حملات دعم مالي وخيري' : 'Charitable Support'}</option>
                <option value="Religious">{isRtl ? 'شعيرة ومجلس ديني' : 'Religious Board'}</option>
                <option value="Virtual">{isRtl ? 'ندوة إنترنت رقمية' : 'Virtual / Zoom Link'}</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1">{isRtl ? 'الموقع أو رابط اللقاء' : 'Location or meeting URL'}</label>
              <input
                type="text"
                required
                placeholder={isRtl ? 'مثال: حديقة الصفا (دبي)، رابط زووم التفاعلي' : 'e.g. Queen Elizabeth Park, Zoom Video'}
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-805 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1">{isRtl ? 'شرح كافٍ عن جدول المناسبة' : 'Description schedule'}</label>
              <textarea
                required
                rows={2}
                placeholder={isRtl ? 'اكتب ترحيباً وبرنامج الحفل والمستلزمات للتنسيق...' : 'Explain program details, age limits, food configurations...'}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full p-2.5 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-805 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green leading-relaxed"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2.5 pt-1">
            <button
              type="button"
              onClick={() => setIsFormOpen(false)}
              className="px-4 py-2 border border-slate-200 dark:border-zinc-800 text-slate-500 rounded text-xs font-semibold cursor-pointer"
            >
              {isRtl ? 'إلغاء' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-sudan-green hover:bg-emerald-800 text-white rounded text-xs font-semibold flex items-center gap-1 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isRtl ? 'إشهار وتنظيم المناسبة' : 'Organize and Post'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Events display cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {events.map((evt) => (
          <div
            key={evt.id}
            className="bg-white dark:bg-zinc-950 rounded-xl overflow-hidden border border-slate-200 dark:border-zinc-850 hover:border-sudan-gold/60 transition-all flex flex-col justify-between"
          >
            <div className="p-4 space-y-3">
              {/* Top metadata */}
              <div className="flex justify-between items-start gap-1">
                <span className="text-[10px] bg-emerald-50 dark:bg-emerald-950/20 text-sudan-green px-2.5 py-0.5 rounded font-bold uppercase tracking-wider font-mono">
                  {evt.category}
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  {new Date(evt.datetime).toLocaleDateString(language === 'ar' ? 'ar-SD' : 'en-US', {
                    weekday: 'short',
                    month: 'short',
                    day: 'numeric',
                  })}
                </span>
              </div>

              <h4 className="text-sm font-bold text-slate-850 dark:text-slate-100 font-cairo">
                {evt.title}
              </h4>

              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed font-sans">
                {evt.description}
              </p>

              <div className="pt-2 grid grid-cols-2 gap-2 text-[11px] text-slate-500 dark:text-slate-450 border-t border-slate-100 dark:border-zinc-900 font-cairo">
                <div>
                  👤 {isRtl ? 'المنظم: ' : 'Body: '}<span className="font-semibold text-slate-700 dark:text-slate-350">{evt.organizer}</span>
                </div>
                <div>
                  📍 {isRtl ? 'المكان: ' : 'Loc: '}<span className="font-semibold text-rose-500">{evt.location}</span>
                </div>
              </div>
            </div>

            {/* RSVP Section footer */}
            <div className="bg-slate-50 dark:bg-zinc-900/40 p-3 border-t border-slate-100 dark:border-zinc-900 flex justify-between items-center text-xs">
              <span className="text-[11px] text-slate-500 flex items-center gap-1">
                <Users className="w-3.5 h-3.5 text-sudan-gold" />
                <span>
                  {evt.rsvps} {isRtl ? 'سودانياً سيحضرون' : 'Sudanese going'}
                </span>
              </span>

              <button
                onClick={() => onRsvp(evt.id)}
                className={`py-1.5 px-3.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shadow-xs ${
                  evt.userRsvped
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400'
                    : 'bg-sudan-green hover:bg-emerald-800 text-white'
                }`}
              >
                {evt.userRsvped ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>{isRtl ? 'مسجل كذاهب! 🎉' : 'Attending 🎉'}</span>
                  </>
                ) : (
                  <span>{isRtl ? 'تأكيد الحضور (سجلني)' : 'RSVP: I am going'}</span>
                )}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
