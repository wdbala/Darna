/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Copy, Check, FileText, Sparkles, BookOpen, HeartHandshake } from 'lucide-react';
import { flutterCodeook } from '../flutterCodebook';

interface DeveloperHubProps {
  language: 'en' | 'ar';
}

export default function DeveloperHub({ language }: DeveloperHubProps) {
  const [selectedFileIdx, setSelectedFileIdx] = useState(0);
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  const selectedFile = flutterCodeook[selectedFileIdx];

  const handleCopyCode = async (code: string, idx: number) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedIdx(idx);
      setTimeout(() => setCopiedIdx(null), 2500);
    } catch (err) {
      console.error('Failed to copy code to clipboard', err);
    }
  };

  const isRtl = language === 'ar';

  return (
    <div className="space-y-6 animate-fade-in font-cairo">
      {/* Introduction Banner */}
      <div className="bg-gradient-to-r from-emerald-800 to-teal-900 text-white p-6 rounded-2xl shadow-md border-b-4 border-sudan-gold relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-[0.05] pointer-events-none transform rotate-12">
          <Sparkles className="w-48 h-48" />
        </div>
        <div className="relative z-10 max-w-2xl">
          <span className="bg-sudan-gold/20 text-sudan-gold border border-sudan-gold/30 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider inline-flex items-center gap-1.5 mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            {isRtl ? 'بوابة المبرمجين' : 'Flutter Mobile SDK Codebase'}
          </span>
          <h2 className="text-2xl font-bold font-cairo">
            {isRtl ? 'تطبيق دارنا للهواتف الذكية (Flutter SDK)' : 'Darna Mobile Application Core Files'}
          </h2>
          <p className="text-xs text-slate-200 mt-2 leading-relaxed">
            {isRtl
              ? 'نهدي مبرمجي وجالية السودان الكود المصدري الأصلي للتطبيق مبنياً بلغة Dart وإطار Flutter. تم دمج Firebase Auth لتسجيل الدخول، وCloud Firestore لإرسال وجلب البيانات التفاعلية في صالة التواصل، ودليل الخدمات، وخرائط Google Maps العالمية.'
              : 'Complementary to our responsive web companion, we have generated the complete production-grade Flutter codebase for Darna. This code manages Firebase Auth, Cloud Firestore real-time listening collections, Google Maps Pins, and bilingual RTL layouts.'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar file navigator */}
        <div className="space-y-2 lg:col-span-1">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest px-2">
            {isRtl ? 'مستكشف كود Dart' : 'Dart Source Files'}
          </h3>
          <div className="space-y-1 mt-2">
            {flutterCodeook.map((file, idx) => (
              <button
                key={file.filename}
                onClick={() => setSelectedFileIdx(idx)}
                className={`w-full text-left p-3 rounded-lg flex items-start gap-2.5 transition-all text-xs border ${
                  selectedFileIdx === idx
                    ? 'bg-emerald-50 border-emerald-300 text-sudan-green font-bold dark:bg-zinc-900/80 dark:border-sudan-green dark:text-emerald-400'
                    : 'bg-white border-slate-100 hover:bg-slate-50 text-slate-600 dark:bg-zinc-950 dark:border-zinc-900 dark:text-slate-300 dark:hover:bg-zinc-900'
                }`}
              >
                <FileText className={`w-4 h-4 mt-0.5 flex-shrink-0 ${selectedFileIdx === idx ? 'text-sudan-green' : 'text-slate-400'}`} />
                <div className="overflow-hidden">
                  <div className="truncate font-mono font-medium">{file.filename}</div>
                  <div className="text-[10px] text-slate-400 dark:text-slate-500 truncate mt-0.5">
                    {file.filename.includes('auth')
                      ? (isRtl ? 'إدارة المصادقة' : 'Sign-in & Sessions')
                      : file.filename.includes('feed')
                      ? (isRtl ? 'خادم الاتصال الحي' : 'Community streams')
                      : file.filename.includes('maps')
                      ? (isRtl ? 'خرائط جوجل والخرائط' : 'Google Maps integration')
                      : file.filename.includes('theme')
                      ? (isRtl ? 'الألوان والتصميم' : 'Cultural Themes')
                      : (isRtl ? 'الدردشة والاتصال' : 'Private Chats Core')}
                  </div>
                </div>
              </button>
            ))}
          </div>

          <div className="bg-amber-50 dark:bg-zinc-950 border border-amber-200 dark:border-amber-900/40 p-3 rounded-lg text-xs space-y-2 text-amber-900 dark:text-amber-400 mt-4">
            <div className="font-bold flex items-center gap-1">
              <BookOpen className="w-3.5 h-3.5" />
              {isRtl ? 'إرشادات النشر والتشغيل' : 'Deployment Guide'}
            </div>
            <p className="text-[10px] leading-relaxed opacity-90">
              {isRtl
                ? 'انسخ هذه الملفات ومكّن Firebase في مشروعك للتمتع بتسجيل دخول حقيقي بالهاتف، ووضع دبابيس حقيقية بالخريطة لتغطية مواقع السودانيين بالدليل.'
                : 'Copy these Dart classes directly into your Flutter /lib project. Make sure you load flutter_google_maps and firebase_core dependencies inside your pubspec.yaml file.'}
            </p>
          </div>
        </div>

        {/* Code Reader */}
        <div className="lg:col-span-3 bg-slate-900 dark:bg-black rounded-2xl overflow-hidden border border-slate-800 flex flex-col h-[540px]">
          <div className="bg-slate-800/80 px-4 py-3 flex items-center justify-between border-b border-slate-700/60">
            <div className="flex items-center gap-2">
              <div className="flex gap-1.5">
                <span className="w-3 h-3 rounded-full bg-red-500"></span>
                <span className="w-3 h-3 rounded-full bg-yellow-500"></span>
                <span className="w-3 h-3 rounded-full bg-green-500"></span>
              </div>
              <span className="text-[11px] font-mono text-slate-350 ml-2">
                lib/src/{selectedFile.filename}
              </span>
            </div>
            <button
              onClick={() => handleCopyCode(selectedFile.code, selectedFileIdx)}
              className="flex items-center gap-1.5 bg-slate-700 hover:bg-slate-600 text-white px-2.5 py-1.5 rounded-md text-[10px] transition-all font-sans cursor-pointer focus:ring-2 focus:ring-emerald-500"
            >
              {copiedIdx === selectedFileIdx ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span>{isRtl ? 'نسِخ!' : 'Copied!'}</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span>{isRtl ? 'نسخ الكود' : 'Copy File'}</span>
                </>
              )}
            </button>
          </div>

          <div className="p-4 bg-slate-800 border-b border-slate-700">
            <span className="text-slate-400 text-[10px] uppercase font-mono block">FILE PURPOSE:</span>
            <span className="text-white text-xs font-semibold leading-relaxed">
              {selectedFile.description}
            </span>
          </div>

          <div className="flex-1 overflow-auto p-4 font-mono text-xs leading-5 text-emerald-400 selection:bg-teal-900 selection:text-white">
            <pre className="whitespace-pre">{selectedFile.code}</pre>
          </div>
        </div>
      </div>
    </div>
  );
}
