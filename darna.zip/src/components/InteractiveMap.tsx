/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { MapPin, Info, Globe, Building } from 'lucide-react';
import { DirectoryService } from '../types';

interface InteractiveMapProps {
  services: DirectoryService[];
  onSelectService: (service: DirectoryService) => void;
  selectedService: DirectoryService | null;
  language: 'en' | 'ar';
}

export default function InteractiveMap({
  services,
  onSelectService,
  selectedService,
  language,
}: InteractiveMapProps) {
  const [hoveredPin, setHoveredPin] = useState<string | null>(null);

  // Core global hubs translated positions representing on visual grid
  // North America (US East / West), UK/Europe, Egypt, Gulf/Saudi, Dubai
  const mapConnections = [
    { from: [38, 28], to: [42, 48], label: 'US-UK Connection' }, // DC to London
    { from: [42, 48], to: [48, 55], label: 'Europe-Nile Connection' }, // London to Cairo
    { from: [48, 55], to: [56, 62], label: 'Cairo-Riyadh Highway' }, // Cairo to Riyadh
    { from: [56, 62], to: [52, 68], label: 'Riyadh-Gulf Gateway' }, // Riyadh to Dubai
  ];

  return (
    <div className="w-full bg-slate-50 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 rounded-xl overflow-hidden shadow-sm relative p-4">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Globe className="w-5 h-5 text-sudan-green animate-spin-slow" />
          <h3 className="text-sm font-semibold font-cairo text-slate-800 dark:text-slate-100">
            {language === 'ar' ? 'خريطة انتشار شبكة دارنا العالمية' : 'Interactive Darna global Network Map'}
          </h3>
        </div>
        <span className="text-[10px] font-mono bg-emerald-100 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-400 px-2 py-0.5 rounded-full flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></span>
          {language === 'ar' ? 'نشط (موقع تقريبي)' : 'Active (approx. location)'}
        </span>
      </div>

      <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
        {language === 'ar'
          ? 'دبابيس خضراء تُمثّل مطاعم، أطباء ومحامين سودانيين. يربط المغتربين بخطوط تواصل حية.'
          : 'Green pins represent Sudanese restaurants, doctors, and legal advisors globally. Click pins to trace.'}
      </p>

      {/* Map visual canvas representation of the globe hubs */}
      <div className="h-[280px] w-full rounded-lg relative overflow-hidden bg-white dark:bg-zinc-950 border border-slate-100 dark:border-zinc-900 pattern-grid">
        {/* World contour outline design */}
        <div className="absolute inset-0 opacity-[0.04] dark:opacity-[0.08] pointer-events-none select-none flex items-center justify-center">
          <div className="text-[12rem] font-bold">SD</div>
        </div>

        {/* Global Connection lines between Diaspora Hubs */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
          {mapConnections.map((line, i) => {
            const x1 = `${line.from[1]}%`;
            const y1 = `${line.from[0]}%`;
            const x2 = `${line.to[1]}%`;
            const y2 = `${line.to[0]}%`;
            return (
              <g key={i}>
                <line
                  x1={x1}
                  y1={y1}
                  x2={x2}
                  y2={y2}
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeDasharray="4,4"
                  className="text-sudan-green/35 dark:text-sudan-green/20"
                />
                <circle cx={x1} cy={y1} r="2" className="fill-sudan-green/30" />
                <circle cx={x2} cy={y2} r="2" className="fill-sudan-green/30" />
              </g>
            );
          })}
        </svg>

        {/* Dynamic map lines detailing regions */}
        <div className="absolute bottom-2 left-2 text-[9px] font-mono text-slate-400 dark:text-slate-600 flex flex-col gap-0.5">
          <div>LAT REF: Sudan Hub (+15.5007° N, 32.5599° E)</div>
          <div>MERIDIAN SCALE: Multi-cluster Active</div>
        </div>

        {/* Floating geographic grid references to resemble real Google Maps layout */}
        <div className="absolute inset-0 pointer-events-none border border-slate-100 dark:border-zinc-900/60 grid grid-cols-6 grid-rows-4 opacity-30">
          {Array.from({ length: 24 }).map((_, i) => (
            <div key={i} className="border-t border-l border-slate-200 dark:border-zinc-800 text-[8px] font-mono p-0.5 text-slate-300 dark:text-zinc-800">
              {i % 2 === 0 ? `Grid-${i * 10}` : ''}
            </div>
          ))}
        </div>

        {/* Custom interactive service markers */}
        {services.map((svc) => {
          const isSelected = selectedService?.id === svc.id;
          const isHovered = hoveredPin === svc.id;

          return (
            <div
              key={svc.id}
              className="absolute -translate-x-1/2 -translate-y-1/2 transition-all duration-300 cursor-pointer"
              style={{ top: `${svc.lat}%`, left: `${svc.lng}%` }}
              onClick={() => onSelectService(svc)}
              onMouseEnter={() => setHoveredPin(svc.id)}
              onMouseLeave={() => setHoveredPin(null)}
            >
              {/* Outer wave ring */}
              <span
                className={`absolute inline-flex h-8 w-8 -top-2.5 -left-2.5 rounded-full opacity-75 animate-ping duration-1000 ${
                  isSelected ? 'bg-sudan-green/40' : 'bg-emerald-400/25'
                }`}
              ></span>

              {/* Pin Icon with dynamic coloring */}
              <div
                className={`relative px-2 py-1 rounded-lg text-white font-sans text-[10px] flex items-center gap-1 transition-all duration-200 shadow-md ${
                  isSelected
                    ? 'bg-sudan-red scale-110 z-30'
                    : isHovered
                    ? 'bg-sudan-gold scale-105 z-20 shadow-lg'
                    : 'bg-sudan-green z-10'
                }`}
              >
                <MapPin className="w-3 h-3 flex-shrink-0" />
                <span className="font-semibold max-w-[80px] truncate">
                  {language === 'ar' ? getArabicCategory(svc.category) : svc.name.split(' ')[0]}
                </span>
              </div>

              {/* Tiny pointer arrow at bottom of label */}
              <div
                className={`w-1.5 h-1.5 rotate-45 mx-auto -mt-1 shadow-sm ${
                  isSelected ? 'bg-sudan-red' : isHovered ? 'bg-sudan-gold' : 'bg-sudan-green'
                }`}
              ></div>

              {/* Hover Tooltip / Label */}
              {(isHovered || isSelected) && (
                <div className="absolute top-8 left-1/2 -translate-x-1/2 bg-slate-900 border border-slate-800 text-slate-100 text-[10px] p-2 rounded shadow-2xl z-40 w-44 pointer-events-none font-cairo">
                  <div className="font-bold flex items-center gap-1">
                    <Building className="w-2.5 h-2.5 text-sudan-gold" />
                    {svc.name}
                  </div>
                  <div className="text-[9px] text-slate-400 mt-1">{svc.address}</div>
                  <div className="text-[9px] text-emerald-400 font-mono mt-0.5">{svc.phone}</div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Selected Detail widget below map */}
      {selectedService ? (
        <div className="mt-4 p-3 bg-white dark:bg-zinc-950 border border-emerald-500/30 rounded-lg animate-fade-in shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-50 dark:bg-emerald-950/40 text-sudan-green px-2 py-0.5 rounded">
                {language === 'ar' ? getArabicCategory(selectedService.category) : selectedService.category}
              </span>
              <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mt-1 font-cairo">
                {selectedService.name}
              </h4>
            </div>
            <div className="flex items-center gap-0.5 text-amber-500">
              <span className="text-xs font-bold mr-1">{selectedService.rating}</span>
              {"★".repeat(Math.floor(selectedService.rating))}
            </div>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 px-1">
            {selectedService.description}
          </p>
          <div className="mt-3 pt-2 border-t border-slate-100 dark:border-zinc-900 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-slate-500 dark:text-slate-400">
            <div>📍 <span className="font-semibold">{selectedService.address}</span></div>
            <div>📞 <span className="font-semibold text-emerald-600 dark:text-emerald-400">{selectedService.phone}</span></div>
            {selectedService.website && (
              <div>🌐 <a href={selectedService.website} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">{selectedService.website}</a></div>
            )}
          </div>
        </div>
      ) : (
        <div className="mt-4 p-2.5 bg-slate-100/55 dark:bg-zinc-950/40 border border-dashed border-slate-200 dark:border-zinc-800/80 rounded-lg text-center flex items-center justify-center gap-2 text-xs text-slate-500 dark:text-slate-400">
          <Info className="w-3.5 h-3.5 text-sudan-green" />
          <span>
            {language === 'ar'
              ? 'اضغط على دبابيس الخريطة لعرض تفاصيل الدليل والخدمة'
              : 'Tap icons on map to isolate particular Sudanese services & details.'}
          </span>
        </div>
      )}
    </div>
  );
}

function getArabicCategory(cat: string): string {
  switch (cat) {
    case 'Restaurant':
      return 'مطعم سوداني';
    case 'Doctor':
      return 'طبيب مختص';
    case 'Lawyer':
      return 'محاماة وهجرة';
    case 'Advisor':
      return 'استشاري جالية';
    case 'Shipping':
      return 'شحن دولي مالي';
    case 'Grocer':
      return 'بقالة حلال';
    case 'Cultural':
      return 'ملتقى ثقافي';
    default:
      return 'خدمة ممتازة';
  }
}
