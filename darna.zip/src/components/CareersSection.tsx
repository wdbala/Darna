/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Briefcase, CircleDollarSign, Check, Mail, Phone, MapPin, Search, Calendar, FileText, Send, X } from 'lucide-react';
import { JobPost } from '../types';

interface CareersSectionProps {
  jobPosts: JobPost[];
  onAddJobPost: (newJob: Omit<JobPost, 'id' | 'datetime'>) => void;
  language: 'en' | 'ar';
}

export default function CareersSection({ jobPosts, onAddJobPost, language }: CareersSectionProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('All');
  
  // Create Job Listing form fields
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [company, setCompany] = useState('');
  const [location, setLocation] = useState('');
  const [salary, setSalary] = useState('');
  const [type, setType] = useState<'Full-time' | 'Part-time' | 'Remote' | 'Contract'>('Full-time');
  const [description, setDescription] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');

  // Apply workflow fields
  const [applyJob, setApplyJob] = useState<JobPost | null>(null);
  const [applicantName, setApplicantName] = useState('');
  const [applicantEmail, setApplicantEmail] = useState('');
  const [applicantPhone, setApplicantPhone] = useState('');
  const [appliedSuccess, setAppliedSuccess] = useState(false);

  const handleCreateJob = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !company || !location || !description) return;
    onAddJobPost({
      title,
      company,
      location,
      salary: salary || 'N/A',
      type,
      description,
      contactEmail,
      contactPhone,
    });
    // Reset
    setTitle('');
    setCompany('');
    setLocation('');
    setSalary('');
    setDescription('');
    setContactEmail('');
    setContactPhone('');
    setIsFormOpen(false);
  };

  const handleApplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!applicantName || !applicantEmail) return;
    setAppliedSuccess(true);
    setTimeout(() => {
      setAppliedSuccess(false);
      setApplyJob(null);
      setApplicantName('');
      setApplicantEmail('');
      setApplicantPhone('');
    }, 2800);
  };

  const isRtl = language === 'ar';

  // Filters
  const filteredJobs = jobPosts.filter((job) => {
    const matchesSearch =
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'All' || job.type === filterType;
    return matchesSearch && matchesType;
  });

  const listLabels = {
    All: isRtl ? 'الكل' : 'All Arrangements',
    'Full-time': isRtl ? 'دوام كامل' : 'Full-time',
    'Part-time': isRtl ? 'دوام جزئي' : 'Part-time',
    Remote: isRtl ? 'عمل عن بعد' : 'Remote Job',
    Contract: isRtl ? 'عقد مؤقت' : 'Contract',
  };

  return (
    <div className="space-y-6 animate-fade-in font-cairo">
      {/* Search Header and Advertise button */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:max-w-md">
          <Search className="absolute top-2.5 right-3 w-4 h-4 text-slate-400 dark:text-zinc-500" />
          <input
            type="text"
            placeholder={isRtl ? 'البحث عن فرص توظيف أو جهات عمل...' : 'Search careers and companies...'}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full py-2 bg-white dark:bg-zinc-950 text-slate-800 dark:text-zinc-100 border border-slate-200 dark:border-zinc-805 rounded-lg text-xs outline-none focus:border-sudan-green transition-all ${
              isRtl ? 'pr-3 pl-10 text-right' : 'pl-3 pr-10 text-left'
            }`}
          />
        </div>

        <div className="flex flex-wrap gap-2 items-center justify-end w-full md:w-auto">
          {/* Quick classification toggle */}
          <div className="flex gap-1 overflow-x-auto">
            {['All', 'Full-time', 'Part-time', 'Remote', 'Contract'].map((tName) => (
              <button
                key={tName}
                onClick={() => setFilterType(tName)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  filterType === tName
                    ? 'bg-sudan-green text-white'
                    : 'bg-white text-slate-600 border border-slate-200 dark:bg-zinc-950 dark:border-zinc-850 dark:text-slate-350 dark:hover:bg-zinc-900'
                }`}
              >
                {listLabels[tName as keyof typeof listLabels]}
              </button>
            ))}
          </div>

          <button
            onClick={() => setIsFormOpen(!isFormOpen)}
            className="bg-sudan-green hover:bg-emerald-800 text-white font-bold text-xs px-4 py-2 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer shadow-sm w-full sm:w-auto text-center justify-center"
          >
            <Briefcase className="w-4 h-4" />
            <span>{isFormOpen ? (isRtl ? 'إغلاق الإعلان' : 'Close Post Form') : (isRtl ? 'أعلن عن وظيفة شاغرة 🇸🇩' : 'Advertise Job')}</span>
          </button>
        </div>
      </div>

      {/* Collapse Post Form */}
      {isFormOpen && (
        <form onSubmit={handleCreateJob} className="bg-slate-50 dark:bg-zinc-900/60 p-5 rounded-xl border border-slate-200 dark:border-zinc-800 animate-slide-down space-y-4">
          <div className="flex justify-between items-center border-b border-slate-200 dark:border-zinc-800 pb-2">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 font-cairo">
              {isRtl ? 'تفاصيل إشهار فرصة عمل للجالية' : 'Provide Career Opportunities detail'}
            </h3>
            <span className="text-[10px] bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300 px-2.5 py-0.5 rounded font-mono">NEW POST</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">{isRtl ? 'المسمى الوظيفي' : 'Job Title'}</label>
              <input
                type="text"
                required
                placeholder={isRtl ? 'مثال: مهندس برمجيات، محاسب مالي، طباخ أطعمة' : 'e.g. Accountant, Site Engineer, Chef'}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">{isRtl ? 'اسم جهة العمل / الشركة' : 'Company Name'}</label>
              <input
                type="text"
                required
                placeholder={isRtl ? 'مثال: شركة النيل للتجارة، مستودع الأدوية' : 'e.g. Nile Engineering, Private Clinic'}
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">{isRtl ? 'الموقع الجغرافي (المدينة، الدولة)' : 'Location (City, Country)'}</label>
              <input
                type="text"
                required
                placeholder={isRtl ? 'مثال: لندن (المملكة المتحدة)، دبي (الإمارات)، الرياض' : 'e.g. Riyadh (KSA), London (UK), Cairo'}
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">{isRtl ? 'الراتب المتوقع أو المقابل المادي' : 'Estimated Salary / Rate'}</label>
              <input
                type="text"
                placeholder={isRtl ? 'مثال: 5,000 ريال شهرياً، 30$ بالساعة' : 'e.g. $4,000 / month, competitive'}
                value={salary}
                onChange={(e) => setSalary(e.target.value)}
                className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">{isRtl ? 'نوع العمل' : 'Arrangement Type'}</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 text-slate-700 dark:text-slate-300 rounded text-xs outline-none focus:border-sudan-green"
              >
                <option value="Full-time">{isRtl ? 'دوام كامل' : 'Full-time'}</option>
                <option value="Part-time">{isRtl ? 'دوام جزئي' : 'Part-time'}</option>
                <option value="Remote">{isRtl ? 'عمل عن بعد' : 'Remote Location'}</option>
                <option value="Contract">{isRtl ? 'عقد سنوي / مؤقت' : 'Temporary Contract'}</option>
              </select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">{isRtl ? 'البريد للتراسل' : 'Contact Email'}</label>
                <input
                  type="email"
                  placeholder="name@company.com"
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                  className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">{isRtl ? 'هاتف التوظيف' : 'Contact Phone'}</label>
                <input
                  type="text"
                  placeholder="+249 / +966 / +44"
                  value={contactPhone}
                  onChange={(e) => setContactPhone(e.target.value)}
                  className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">{isRtl ? 'شرح المهارات المطلوبة للوظيفة' : 'Skills & Job Description'}</label>
            <textarea
              required
              rows={3}
              placeholder={isRtl ? 'اكتب مهام الوظيفة، والخبرات المطلوبة بوضوح...' : 'Briefly detail primary duties, hours, visa requirements if applicable...'}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-2.5 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green leading-relaxed"
            ></textarea>
          </div>

          <div className="flex justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={() => setIsFormOpen(false)}
              className="px-4 py-2 border border-slate-200 dark:border-zinc-800 text-slate-500 rounded text-xs font-semibold cursor-pointer"
            >
              {isRtl ? 'إلغاء الأمر' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-sudan-green hover:bg-emerald-800 text-white rounded text-xs font-semibold flex items-center gap-1 cursor-pointer"
            >
              <Send className="w-3 h-3" />
              <span>{isRtl ? 'نشر الإعلان الوظيفي' : 'Post Advertisement'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Main Jobs Listings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredJobs.length === 0 ? (
          <div className="col-span-1 md:col-span-2 bg-white dark:bg-zinc-950 p-8 rounded-xl border border-slate-200 dark:border-zinc-800 text-center space-y-2">
            <span className="text-3xl">💼</span>
            <h4 className="text-sm font-bold text-slate-700 dark:text-slate-350">
              {isRtl ? 'نعتذر، لا توجد وظائف تطابق هذا التصنيف حالياً' : 'No career listings fit your description'}
            </h4>
            <p className="text-xs text-slate-400">
              {isRtl ? 'يرجى تغيير فلاتر التصفية أو الإعلان عن فرصة تفيد بها الآخرين!' : 'Try widening your filters or post a job lead for the community.'}
            </p>
          </div>
        ) : (
          filteredJobs.map((job) => (
            <div
              key={job.id}
              className="bg-white dark:bg-zinc-950 p-4 rounded-xl border border-slate-200 dark:border-zinc-850 shadow-sm flex flex-col justify-between hover:border-sudan-gold/50 transition-all group"
            >
              <div>
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] bg-slate-100 dark:bg-zinc-900 text-slate-600 dark:text-slate-400 px-2 py-0.5 rounded font-mono">
                      {job.company}
                    </span>
                    <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mt-1 font-cairo cursor-pointer group-hover:text-sudan-green transition-colors">
                      {job.title}
                    </h4>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-sudan-green border border-emerald-100 dark:bg-emerald-950/30 dark:border-emerald-900/40">
                    {language === 'ar' ? listLabels[job.type as keyof typeof listLabels] : job.type}
                  </span>
                </div>

                <div className="flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-slate-500 dark:text-slate-400 mt-2 font-mono">
                  <span className="flex items-center gap-0.5 text-rose-500">
                    <MapPin className="w-3.5 h-3.5" />
                    {job.location}
                  </span>
                  <span className="flex items-center gap-0.5 text-emerald-600 dark:text-emerald-400 font-sans">
                    <CircleDollarSign className="w-3.5 h-3.5" />
                    {job.salary}
                  </span>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-400 mt-3 pl-1 leading-relaxed border-l-2 border-slate-100 dark:border-zinc-900 py-1">
                  {job.description}
                </p>
              </div>

              {/* Bottom apply and details buttons */}
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-zinc-900 flex justify-between items-center text-[11px]">
                <div className="text-slate-400 font-mono">
                  {new Date(job.datetime).toLocaleDateString(language === 'ar' ? 'ar-SD' : 'en-US', {
                    month: 'short',
                    day: 'numeric',
                  })}
                </div>
                <button
                  onClick={() => setApplyJob(job)}
                  className="bg-sudan-green hover:bg-emerald-800 text-white font-bold px-3py-1 px-4 py-1.5 rounded-md transition-all cursor-pointer shadow-sm"
                >
                  {isRtl ? 'قدّم طلب توظيف' : 'Apply Now'}
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Applied Job Simulator Modal dialog overlay */}
      {applyJob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 rounded-xl w-full max-w-md overflow-hidden relative shadow-2xl p-5 font-cairo">
            <button
              onClick={() => setApplyJob(null)}
              className="absolute top-3 right-3 text-slate-400 hover:text-slate-600 dark:hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {appliedSuccess ? (
              <div className="text-center py-6 space-y-4 animate-fade-in">
                <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-900/40 text-sudan-green mx-auto flex items-center justify-center text-xl font-bold animate-bounce">
                  <Check className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-slate-800 dark:text-slate-100">
                  {isRtl ? 'تم تقديم الطلب ومحاكاته بنجاح!' : 'Application Submitted Successfully!'}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed px-4">
                  {isRtl
                    ? `لقد تم إرسال معلومات سيرتك الذاتية ومؤهلاتك بنجاح إلى شركة: (${applyJob.company}) وسيتراسلون معك هاتفياً على رقمك أو ببريدك الإلكتروني.`
                    : `Your qualifications profile was simulated to ${applyJob.company}. The recruiting manager was alerted, and they will contact you at your email.`}
                </p>
              </div>
            ) : (
              <form onSubmit={handleApplySubmit} className="space-y-4">
                <div>
                  <span className="text-[10px] bg-emerald-50 dark:bg-emerald-950/20 text-sudan-green px-2 py-0.5 rounded font-bold font-mono">
                    {applyJob.company}
                  </span>
                  <h3 className="text-sm font-bold text-slate-850 dark:text-slate-100 mt-1">
                    {isRtl ? 'التسجيل لوظيفة: ' : 'Apply for: '}{applyJob.title}
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-0.5">
                    <MapPin className="w-3.5 h-3.5 text-rose-500" />
                    {applyJob.location}
                  </p>
                </div>

                <div className="border-t border-slate-150 dark:border-zinc-800 pt-3 space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">{isRtl ? 'الاسم الكامل المتقدم' : 'Full Applicant Name'}</label>
                    <input
                      type="text"
                      required
                      placeholder={isRtl ? 'أدخل اسمك المعتمد بالسفارات والمؤسسات' : 'e.g. Tarig Al-Fadil'}
                      value={applicantName}
                      onChange={(e) => setApplicantName(e.target.value)}
                      className="w-full p-2 bg-slate-50 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 text-slate-850 dark:text-slate-100 text-xs rounded outline-none focus:border-sudan-green"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">{isRtl ? 'البريد الإلكتروني' : 'Your Email Cover'}</label>
                    <input
                      type="email"
                      required
                      placeholder="name@gmail.com"
                      value={applicantEmail}
                      onChange={(e) => setApplicantEmail(e.target.value)}
                      className="w-full p-2 bg-slate-50 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 text-slate-850 dark:text-slate-100 text-xs rounded outline-none focus:border-sudan-green"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">{isRtl ? 'رقم الهاتف للتواصل بالواتساب' : 'WhatsApp Phone'}</label>
                    <input
                      type="text"
                      required
                      placeholder="+249..."
                      value={applicantPhone}
                      onChange={(e) => setApplicantPhone(e.target.value)}
                      className="w-full p-2 bg-slate-50 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 text-slate-850 dark:text-slate-100 text-xs rounded outline-none focus:border-sudan-green"
                    />
                  </div>

                  {/* Attachment mock widget */}
                  <div className="border border-dashed border-slate-250 dark:border-zinc-800 p-3 rounded text-center text-xs text-slate-400 bg-slate-50/50 dark:bg-zinc-900/30">
                    <FileText className="w-5 h-5 mx-auto text-slate-400 mb-1" />
                    <span>{isRtl ? 'تم تحميل ملف Resume الافتراضي بنجاح (Darna_Card_SD_CV.pdf)' : 'Darna_Profile_CV.pdf automatically loaded'}</span>
                  </div>
                </div>

                <div className="flex gap-2 justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => setApplyJob(null)}
                    className="px-4 py-2 border border-slate-200 dark:border-zinc-800 text-slate-500 rounded text-xs font-semibold cursor-pointer"
                  >
                    {isRtl ? 'تراجع' : 'Close'}
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-sudan-green hover:bg-emerald-800 text-white rounded text-xs font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <Send className="w-3 h-3" />
                    <span>{isRtl ? 'أكد إرسال الطلب الوظيفي' : 'Verify and Apply'}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
