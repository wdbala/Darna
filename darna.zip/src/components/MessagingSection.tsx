/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, User, BadgeAlert, CheckCheck, Landmark } from 'lucide-react';
import { ChatThread, ChatMessage } from '../types';

interface MessagingSectionProps {
  threads: ChatThread[];
  messages: ChatMessage[];
  currentThreadId: string | null;
  onSelectThread: (threadId: string) => void;
  onSendMessage: (text: string) => void;
  language: 'en' | 'ar';
}

export default function MessagingSection({
  threads,
  messages,
  currentThreadId,
  onSelectThread,
  onSendMessage,
  language,
}: MessagingSectionProps) {
  const [typedMsgText, setTypedMsgText] = useState('');
  const msgEndRef = useRef<HTMLDivElement | null>(null);

  const activeThread = threads.find((t) => t.id === currentThreadId);
  const activeMessages = messages.filter(
    (m) =>
      currentThreadId &&
      ((m.senderId === 'me' && m.receiverId === activeThread?.participantId) ||
        (m.senderId === activeThread?.participantId && m.receiverId === 'me'))
  );

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!typedMsgText.trim()) return;
    onSendMessage(typedMsgText.trim());
    setTypedMsgText('');
  };

  useEffect(() => {
    msgEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeMessages]);

  const isRtl = language === 'ar';

  return (
    <div className="bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-850 rounded-2xl overflow-hidden shadow-sm grid grid-cols-1 md:grid-cols-3 h-[525px] font-cairo">
      {/* Threads Sidebar col */}
      <div className="md:col-span-1 border-r border-slate-250 dark:border-zinc-900 flex flex-col justify-between h-full bg-slate-50/50 dark:bg-zinc-950/20">
        <div className="p-3 border-b border-slate-100 dark:border-zinc-900 bg-white dark:bg-zinc-950">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">
            {isRtl ? 'المحادثات النشطة بدارنا' : 'Darna Secure Conversations'}
          </h3>
          <p className="text-[10px] text-slate-450 dark:text-slate-500 mt-1">
            {isRtl ? 'مشفرة وتعمل بنبض فوري مع البائعين والوظائف' : 'Direct connection with community members'}
          </p>
        </div>

        {/* Threads List container */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {threads.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-400">
              {isRtl ? 'لا توجد محادثات جارية حالياً' : 'No active inquiries'}
            </div>
          ) : (
            threads.map((th) => {
              const isSelected = currentThreadId === th.id;
              return (
                <button
                  key={th.id}
                  onClick={() => onSelectThread(th.id)}
                  className={`w-full text-left p-3 rounded-xl flex items-center justify-between gap-2.5 transition-all outline-none cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-50 dark:bg-zinc-900 border border-emerald-250 dark:border-sudan-green/40'
                      : 'border border-transparent hover:bg-slate-50 dark:hover:bg-zinc-900/40'
                  }`}
                >
                  <div className="flex items-center gap-2.5 overflow-hidden">
                    <span className="w-9 h-9 rounded-full bg-slate-100 dark:bg-zinc-900 flex items-center justify-center text-lg shadow-inner select-none flex-shrink-0">
                      {th.participantAvatar}
                    </span>
                    <div className={`overflow-hidden ${isRtl ? 'text-right' : 'text-left'}`}>
                      <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 truncate">
                        {th.participantName}
                      </h4>
                      <p className="text-[10.5px] text-slate-450 dark:text-slate-400 truncate mt-0.5 font-normal">
                        {th.lastMessage}
                      </p>
                    </div>
                  </div>

                  {/* Badges details */}
                  <div className="flex flex-col items-end flex-shrink-0 justify-between h-8">
                    <span className="text-[9px] text-slate-400">
                      {new Date(th.timestamp).toLocaleTimeString(isRtl ? 'ar' : 'en', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                    {th.unreadCount > 0 && (
                      <span className="w-4 h-4 rounded-full bg-sudan-red text-white text-[9px] flex items-center justify-center font-bold animate-pulse">
                        {th.unreadCount}
                      </span>
                    )}
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Info label */}
        <div className="p-3 border-t border-slate-100 dark:border-zinc-900 bg-white dark:bg-zinc-950 text-[10px] text-slate-400 leading-relaxed text-center flex items-center justify-center gap-1">
          <Sparkles className="w-3 h-3 text-sudan-gold" />
          <span>{isRtl ? 'الرد التلقائي للمحاكاة مفعّل للكشف والمراجعة' : 'Simulation responder active for sandbox'}</span>
        </div>
      </div>

      {/* Messages Feed panel */}
      <div className="md:col-span-2 flex flex-col justify-between h-full bg-slate-50/20 dark:bg-zinc-900/20">
        {activeThread ? (
          <>
            {/* Header chat detail */}
            <div className="bg-white dark:bg-zinc-950 px-4 py-3 border-b border-slate-100 dark:border-zinc-900 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="w-8 h-8 rounded-full bg-slate-100 dark:bg-zinc-900 flex items-center justify-center text-lg select-none">
                  {activeThread.participantAvatar}
                </span>
                <div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100">
                    {activeThread.participantName}
                  </h4>
                  <span className="text-[9.5px] text-emerald-600 dark:text-emerald-400 flex items-center gap-1 font-mono">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></span>
                    {isRtl ? 'نشط بالمنصة' : 'active globally'}
                  </span>
                </div>
              </div>
            </div>

            {/* Message streams bubbles */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
              {activeMessages.map((msg) => {
                const isMyMessage = msg.senderId === 'me';
                return (
                  <div
                    key={msg.id}
                    className={`flex ${isMyMessage ? 'justify-end' : 'justify-start'} animate-fade-in`}
                  >
                    <div
                      className={`max-w-[75%] rounded-2xl p-3 text-xs shadow-xs leading-relaxed ${
                        isMyMessage
                          ? 'bg-sudan-green text-white rounded-br-none'
                          : 'bg-white text-slate-800 dark:bg-zinc-950 dark:text-slate-200 rounded-bl-none border border-slate-200/50 dark:border-zinc-900'
                      }`}
                    >
                      <p className={isRtl ? 'text-right' : 'text-left'}>{msg.text}</p>
                      
                      <div
                        className={`text-[9px] mt-1.5 flex items-center gap-1 ${
                          isMyMessage ? 'text-emerald-250 justify-end' : 'text-slate-400 justify-start'
                        }`}
                      >
                        <span>
                          {new Date(msg.timestamp).toLocaleTimeString(isRtl ? 'ar' : 'en', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                        {isMyMessage && <CheckCheck className="w-3.5 h-3.5" />}
                      </div>
                    </div>
                  </div>
                );
              })}
              <div ref={msgEndRef}></div>
            </div>

            {/* Form messaging input text */}
            <form
              onSubmit={handleSend}
              className="bg-white dark:bg-zinc-950 p-3 border-t border-slate-100 dark:border-zinc-900 flex gap-2 items-center"
            >
              <input
                type="text"
                placeholder={isRtl ? 'اكتب رسالتك لولد بلدك للتسوق والتعيين...' : 'Write private message response...'}
                value={typedMsgText}
                onChange={(e) => setTypedMsgText(e.target.value)}
                className={`flex-1 p-2 bg-slate-50 dark:bg-zinc-905 bg-slate-50 dark:bg-zinc-900 text-slate-800 dark:text-zinc-150 border border-slate-200 dark:border-zinc-800 rounded-xl text-xs outline-none focus:border-sudan-green ${
                  isRtl ? 'text-right' : 'text-left'
                }`}
              />
              <button
                type="submit"
                disabled={!typedMsgText.trim()}
                className="bg-sudan-green hover:bg-emerald-800 text-white rounded-xl p-2.5 transition-all disabled:opacity-40 cursor-pointer text-center flex items-center justify-center shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-400 space-y-3 font-cairo">
            <span className="text-4xl animate-pulse">💬</span>
            <div className="space-y-1">
              <h4 className="text-xs font-bold text-slate-600 dark:text-slate-400">
                {isRtl ? 'لم تختر أي محادثة للدردشة' : 'Select Conversation Thread'}
              </h4>
              <p className="text-[11px] text-slate-450 dark:text-slate-500 max-w-xs leading-relaxed">
                {isRtl
                  ? 'اضغط على ترويسة أي عضو من القائمة بالجانب لبدء كتابة الرسائل الآمنة للمصادقة وتفاصيل العقد!'
                  : 'Click on any companion thread in the list to trigger immediate, robust real-time dialogues.'}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
