/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { ShoppingBag, CircleDollarSign, Plus, Eye, Send, MapPin, Search } from 'lucide-react';
import { MarketplaceItem } from '../types';

interface SouqSectionProps {
  marketplaceItems: MarketplaceItem[];
  onAddMarketplaceItem: (newItem: Omit<MarketplaceItem, 'id' | 'datetime'>) => void;
  onInitiateSellerChat: (item: MarketplaceItem) => void;
  language: 'en' | 'ar';
}

export default function SouqSection({
  marketplaceItems,
  onAddMarketplaceItem,
  onInitiateSellerChat,
  language,
}: SouqSectionProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  
  // Post item form fields
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState<'Furniture' | 'Clothing' | 'Electronics' | 'Traditional' | 'Other'>('Traditional');
  const [location, setLocation] = useState('');
  const [condition, setCondition] = useState<'Brand New' | 'Like New' | 'Good' | 'Fair'>('Brand New');
  const [description, setDescription] = useState('');

  const handlePostItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !price || !location || !description) return;
    onAddMarketplaceItem({
      title,
      price: price.startsWith('$') ? price : `$${price}`,
      category,
      location,
      condition,
      description,
      sellerId: 'u_me',
      sellerName: 'My Profile (Seller)',
      sellerPhone: '+249 912 345 678',
    });
    // Reset
    setTitle('');
    setPrice('');
    setLocation('');
    setDescription('');
    setIsFormOpen(false);
  };

  const isRtl = language === 'ar';

  const categoryLabels = {
    All: isRtl ? 'الكل' : 'All Goods',
    Furniture: isRtl ? 'أثاث ومفروشات' : 'Furniture',
    Clothing: isRtl ? 'ثياب سودانية وملابس' : 'Clothing',
    Electronics: isRtl ? 'إلكترونيات وجوالات' : 'Mobiles & Tech',
    Traditional: isRtl ? 'بخور، عطور وتوابل تراثية 🇸🇩' : 'Traditional Heritage 🇸🇩',
    Other: isRtl ? 'سلع عامة مخفضة' : 'General Sales',
  };

  const categoryIcons = {
    Furniture: '🛋️',
    Clothing: '👗',
    Electronics: '📱',
    Traditional: '🏺',
    Other: '📦',
  };

  const conditionLabels = {
    'Brand New': isRtl ? 'جديد كلياً' : 'Brand New',
    'Like New': isRtl ? 'كأنه جديد' : 'Like New',
    Good: isRtl ? 'حالة جيدة' : 'Good Condition',
    Fair: isRtl ? 'مستعمل مقبول' : 'Fairly Used',
  };

  // Filters
  const filteredItems = marketplaceItems.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6 animate-fade-in font-cairo">
      {/* Filters header */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:max-w-md">
          <Search className="absolute top-2.5 right-3 w-4 h-4 text-slate-400 dark:text-zinc-500" />
          <input
            type="text"
            placeholder={isRtl ? 'ابحث في المعروضات كالعطور أو الثياب...' : 'Search Traditional Thobes, Bakhoor...'}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full py-2 bg-white dark:bg-zinc-950 text-slate-800 dark:text-zinc-100 border border-slate-200 dark:border-zinc-800 rounded-lg text-xs outline-none focus:border-sudan-green transition-all ${
              isRtl ? 'pr-3 pl-10 text-right' : 'pl-3 pr-10 text-left'
            }`}
          />
        </div>

        <div className="flex flex-wrap gap-2 items-center justify-end w-full md:w-auto">
          {/* Quick classification toggle */}
          <div className="flex gap-1 overflow-x-auto">
            {['All', 'Traditional', 'Clothing', 'Electronics', 'Furniture', 'Other'].map((cName) => (
              <button
                key={cName}
                onClick={() => setSelectedCategory(cName)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  selectedCategory === cName
                    ? 'bg-sudan-green text-white'
                    : 'bg-white text-slate-600 border border-slate-200 dark:bg-zinc-950 dark:border-zinc-850 dark:text-slate-350 dark:hover:bg-zinc-900'
                }`}
              >
                {categoryLabels[cName as keyof typeof categoryLabels]}
              </button>
            ))}
          </div>

          <button
            onClick={() => setIsFormOpen(!isFormOpen)}
            className="bg-sudan-green hover:bg-emerald-800 text-white font-bold text-xs px-4 py-2 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer shadow-sm w-full sm:w-auto justify-center"
          >
            <Plus className="w-4 h-4" />
            <span>{isFormOpen ? (isRtl ? 'إغلاق الإضافة' : 'Close Form') : (isRtl ? 'عرض بضاعتي بالسوق 🇸🇩' : 'List Item')}</span>
          </button>
        </div>
      </div>

      {/* Collapse Post Form */}
      {isFormOpen && (
        <form onSubmit={handlePostItem} className="bg-slate-50 dark:bg-zinc-900/65 p-5 rounded-xl border border-slate-200 dark:border-zinc-800 animate-slide-down space-y-4">
          <div className="flex justify-between items-center border-b border-slate-200 dark:border-zinc-800 pb-2">
            <h3 className="text-sm font-bold text-slate-850 dark:text-slate-200 font-cairo">
              {isRtl ? 'أدخل تفاصيل سلعتك الوطنية لعرضها في سوق دارنا' : 'Provide product listing parameters for Souq'}
            </h3>
            <span className="text-[10px] bg-amber-1050 bg-sudan-gold/25 text-[#9E730B] border border-amber-500/20 px-2.5 py-0.5 rounded font-mono">DARNA SOUQ</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">{isRtl ? 'عنوان السلعة' : 'Product Title'}</label>
              <input
                type="text"
                required
                placeholder={isRtl ? 'مثال: ثياب قطن مروي، بخور صندل، عطور سودانية ديلكا' : 'e.g. Handmade Incense Base, traditional silk thobe'}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-805 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">{isRtl ? 'السعر المتوقع (بالدولار أو العملة المحلية)' : 'Price / Value'}</label>
              <input
                type="text"
                required
                placeholder={isRtl ? 'مثال: $45، 150 درهم' : 'e.g. $45, custom trades'}
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-805 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">{isRtl ? 'موقع تسليم البضاعة (المدينة، الدولة)' : 'Pickup Location (City, Country)'}</label>
              <input
                type="text"
                required
                placeholder={isRtl ? 'مثال: دبي، لندن، الرياض، دالاس' : 'e.g. Dallas TX, Cairo Heliopolis'}
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-805 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">{isRtl ? 'التصنيف الرئيسي' : 'Item Category'}</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-805 text-slate-700 dark:text-slate-305 rounded text-xs outline-none focus:border-sudan-green"
                >
                  <option value="Traditional">🏺 {isRtl ? 'توابل صندل وبخور' : 'Traditional Crafts'}</option>
                  <option value="Clothing">👗 {isRtl ? 'ثياب سودانية وملبوسات' : 'Wear & Clothing'}</option>
                  <option value="Electronics">📱 {isRtl ? 'إلكترونيات وهواتف' : 'Electronics & Mobiles'}</option>
                  <option value="Furniture">🛋️ {isRtl ? 'أثاث وفراش منزلي' : 'Furniture & Utilities'}</option>
                  <option value="Other">📦 {isRtl ? 'أخرى متفرقة' : 'General Sales'}</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">{isRtl ? 'حالة السلعة' : 'Condition Status'}</label>
                <select
                  value={condition}
                  onChange={(e) => setCondition(e.target.value as any)}
                  className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-805 text-slate-705 dark:text-slate-305 rounded text-xs outline-none focus:border-sudan-green"
                >
                  <option value="Brand New">{isRtl ? 'جديد كلياً' : 'Brand New'}</option>
                  <option value="Like New">{isRtl ? 'شبه جديد' : 'Like New'}</option>
                  <option value="Good">{isRtl ? 'حالة جيدة' : 'Good'}</option>
                  <option value="Fair">{isRtl ? 'مستعمل مقبول' : 'Fair'}</option>
                </select>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">{isRtl ? 'توصيف السلعة وصورها للتوصيل' : 'Details & Delivery framework'}</label>
            <textarea
              required
              rows={3}
              placeholder={isRtl ? 'اكتب مواصفات السلعة، بلد الصنع ومكان التسليم بوضوح للتواصل' : 'Describe measurements, delivery fees, or contact methods like WhatsApp...'}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-2.5 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-805 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green leading-relaxed"
            ></textarea>
          </div>

          <div className="flex justify-end gap-2.5 pt-1">
            <button
              type="button"
              onClick={() => setIsFormOpen(false)}
              className="px-4 py-2 border border-slate-200 dark:border-zinc-800 text-slate-505 rounded text-xs font-semibold cursor-pointer"
            >
              {isRtl ? 'تراجع' : 'Close'}
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-sudan-green hover:bg-emerald-800 text-white rounded text-xs font-semibold flex items-center gap-1 cursor-pointer"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>{isRtl ? 'انشر بضاعتك الآن بالسوق' : 'List on Souq'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Products Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
        {filteredItems.length === 0 ? (
          <div className="col-span-full bg-white dark:bg-zinc-950 p-8 rounded-xl border border-slate-200 dark:border-zinc-800 text-center space-y-2">
            <span className="text-3xl">🏺</span>
            <h4 className="text-sm font-bold text-slate-755 dark:text-slate-350 font-cairo">
              {isRtl ? 'سوق دارنا خالٍ من المعروضات في هذا القسم حالياً' : 'No items match this category filter'}
            </h4>
            <p className="text-xs text-slate-405">
              {isRtl ? 'يرجى تغيير التصنيف أو نشر أول سلعة بنفسك تسعد بها قلوب الجالية!' : 'Widen your filters or list a Sudanese heritage asset right now.'}
            </p>
          </div>
        ) : (
          filteredItems.map((item) => {
            const hasCrumbs = item.category === 'Traditional' || item.category === 'Clothing';
            return (
              <div
                key={item.id}
                className="bg-white dark:bg-zinc-950 rounded-xl overflow-hidden border border-slate-200 dark:border-zinc-850 hover:border-sudan-green/45 transition-all shadow-sm flex flex-col justify-between group"
              >
                {/* Visual placeholder mimicking graphic card */}
                <div className={`h-36 relative flex items-center justify-center p-4 select-none ${
                  hasCrumbs
                    ? 'bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-950/20 dark:to-teal-950/30'
                    : 'bg-gradient-to-br from-amber-50 to-amber-100 dark:from-zinc-900 dark:to-zinc-950'
                }`}>
                  <span className="text-4xl filter drop-shadow">
                    {categoryIcons[item.category as keyof typeof categoryIcons] || '📦'}
                  </span>
                  
                  {/* Traditional design element */}
                  <span className="absolute top-2 right-2 text-[10px] bg-sudan-green/10 text-sudan-green dark:bg-zinc-900 font-mono px-2 py-0.5 rounded-full font-bold">
                    {language === 'ar' ? conditionLabels[item.condition as keyof typeof conditionLabels] : item.condition}
                  </span>
                </div>

                <div className="p-4 space-y-2">
                  <div className="flex justify-between items-start gap-1">
                    <h4 className="text-xs font-bold text-slate-805 dark:text-slate-105 font-cairo group-hover:text-sudan-green transition-colors mt-0.5 max-w-[170px] truncate">
                      {item.title}
                    </h4>
                    <span className="text-xs font-bold text-sudan-gold font-mono whitespace-nowrap bg-amber-50 dark:bg-zinc-90 w-auto px-2 py-0.5 rounded">
                      {item.price}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-500 dark:text-slate-405 flex items-center gap-0.5 font-mono">
                    <MapPin className="w-3 h-3 text-rose-500" />
                    {item.location}
                  </p>

                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed line-clamp-2 h-8">
                    {item.description}
                  </p>

                  {/* Seller details footer */}
                  <div className="mt-4 pt-3 border-t border-slate-100 dark:border-zinc-900 flex justify-between items-center text-[10px] text-slate-450 dark:text-slate-500 font-cairo">
                    <div>👤 {item.sellerName}</div>
                    <button
                      onClick={() => onInitiateSellerChat(item)}
                      className="bg-sudan-green hover:bg-emerald-800 text-white font-bold px-3 py-1.5 rounded transition-all cursor-pointer text-[10px]"
                    >
                      {isRtl ? 'راسل البائع 💬' : 'Chat Seller'}
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
