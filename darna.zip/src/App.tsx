/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import {
  Bell,
  Sun,
  Moon,
  Globe,
  LogOut,
  MapPin,
  Briefcase,
  ShoppingBag,
  Calendar,
  User,
  Info,
  Lock,
  Volume2,
  FileCheck,
  Building,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

import {
  User as UserType,
  FeedPost,
  JobPost,
  MarketplaceItem,
  DirectoryService,
  CommunityEvent,
  ChatThread,
  ChatMessage,
  AppNotification
} from './types';

import { translations, Language } from './translations';

import {
  initialFeedPosts,
  initialJobPosts,
  initialMarketplaceItems,
  initialDirectoryServices,
  initialCommunityEvents,
  initialChatThreads
} from './mockData';

// Modular children imports
import InteractiveMap from './components/InteractiveMap';
import DeveloperHub from './components/DeveloperHub';
import FeedSection from './components/FeedSection';
import CareersSection from './components/CareersSection';
import SouqSection from './components/SouqSection';
import EventsSection from './components/EventsSection';
import MessagingSection from './components/MessagingSection';

export default function App() {
  // Localization & Styling states
  const [language, setLanguage] = useState<Language>('ar');
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [menuOpen, setMenuOpen] = useState<boolean>(false);

  // Authentication states
  const [user, setUser] = useState<UserType | null>(null);
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authName, setAuthName] = useState('');
  const [authPhone, setAuthPhone] = useState('');
  const [authCity, setAuthCity] = useState('');
  const [authCountry, setAuthCountry] = useState('');
  const [isSignUP, setIsSignUp] = useState(false);
  const [sudaneseConfirmed, setSudaneseConfirmed] = useState(false);

  // OTP Simulated Verification states (Firebase Multi-factor simulator)
  const [verificationMode, setVerificationMode] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [systemOtp, setSystemOtp] = useState('123456');
  const [otpError, setOtpError] = useState(false);

  // Core interactive tables (hydrated from mocks)
  const [feedPosts, setFeedPosts] = useState<FeedPost[]>(initialFeedPosts);
  const [jobPosts, setJobPosts] = useState<JobPost[]>(initialJobPosts);
  const [marketplaceItems, setMarketplaceItems] = useState<MarketplaceItem[]>(initialMarketplaceItems);
  const [directoryServices, setDirectoryServices] = useState<DirectoryService[]>(initialDirectoryServices);
  const [communityEvents, setCommunityEvents] = useState<CommunityEvent[]>(initialCommunityEvents);
  const [chatThreads, setChatThreads] = useState<ChatThread[]>(initialChatThreads);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([
    {
      id: 'n1',
      title: 'Welcome to Darna!',
      body: 'Connecting Sudanese worldwide. You are verified on Sudanese network.',
      timestamp: new Date().toISOString(),
      read: false,
      type: 'news',
    }
  ]);

  // View state coordinates
  const [activeTab, setActiveTab] = useState<'feed' | 'jobs' | 'marketplace' | 'services' | 'events' | 'messaging' | 'profile' | 'devhub'>('feed');
  const [selectedService, setSelectedService] = useState<DirectoryService | null>(null);
  const [currentThreadId, setCurrentThreadId] = useState<string | null>(null);
  
  // Notification dropdown overlay
  const [showNotificationsDropdown, setShowNotificationsDropdown] = useState(false);
  const [notificationBanner, setNotificationBanner] = useState<AppNotification | null>(null);
  const [soundSimulation, setSoundSimulation] = useState(true);

  // Service directory custom creation
  const [isRegServiceOpen, setIsRegServiceOpen] = useState(false);
  const [svcName, setSvcName] = useState('');
  const [svcCategory, setSvcCategory] = useState<'Restaurant' | 'Doctor' | 'Lawyer' | 'Advisor' | 'Shipping' | 'Grocer' | 'Cultural'>('Restaurant');
  const [svcAddress, setSvcAddress] = useState('');
  const [svcPhone, setSvcPhone] = useState('');
  const [svcDesc, setSvcDesc] = useState('');
  const [svcWebsite, setSvcWebsite] = useState('');

  // Audio mock ping on alerts
  const triggerNotificationAlert = (title: string, body: string, category: 'news' | 'chat' | 'marketplace' | 'job' | 'event') => {
    const newAlert: AppNotification = {
      id: 'n_' + Date.now(),
      title,
      body,
      timestamp: new Date().toISOString(),
      read: false,
      type: category,
    };
    setNotifications((prev) => [newAlert, ...prev]);
    setNotificationBanner(newAlert);
    
    // Auto clear banner
    setTimeout(() => {
      setNotificationBanner(null);
    }, 5000);
  };

  // Sync Dark Mode classes inside body
  useEffect(() => {
    const root = window.document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [darkMode]);

  // Bypass sign-in for testing easily
  const handleFastDemoLogin = () => {
    const demoProfile: UserType = {
      id: 'u_101',
      name: 'Yassir Al-Ameen',
      email: 'wdbala1996@gmail.com',
      avatar: '🇸🇩',
      bio: 'Proud pioneer of the Sudanese diaspora. Graduated from University of Khartoum, residing in London, active with youth charity drives.',
      city: 'London',
      country: 'United Kingdom',
      phone: '+44 7911 889312',
    };
    setUser(demoProfile);
    triggerNotificationAlert(
      language === 'ar' ? 'أهلاً بك يا منور دارنا!' : 'Welcome back to Darna!',
      language === 'ar' ? 'تم الدخول السريع بحساب التجربة يسر الأمين 🇸🇩' : 'Quick authenticated via demo profile Yassir Al-Ameen.',
      'news'
    );
  };

  // True simulated login triggers SMS verification modal
  const handleInitialAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (isSignUP) {
      if (!authEmail || !authPassword || !authName || !sudaneseConfirmed) return;
    } else {
      if (!authEmail || !authPassword) return;
    }

    // Set simulator verification passcode
    setSystemOtp('482129');
    setVerificationMode(true);
    setOtpError(false);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (otpCode === '482129' || otpCode === '123456') {
      const newUserProfile: UserType = {
        id: 'u_' + Date.now(),
        name: isSignUP ? authName : authEmail.split('@')[0],
        email: authEmail,
        avatar: '🇸🇩',
        bio: 'Honored member of the worldwide Sudanese digital cluster.',
        city: authCity || 'Cairo',
        country: authCountry || 'Egypt',
        phone: authPhone || '+249 912 345 678',
      };
      setUser(newUserProfile);
      setVerificationMode(false);
      triggerNotificationAlert(
        language === 'ar' ? 'تم تفعيل الحساب وتسجيل الدخول' : 'Session verified & active!',
        language === 'ar' ? `مرحباً بك يا ${newUserProfile.name} في دارنا.` : `Welcome ${newUserProfile.name} to the Sudanese diaspora index.`,
        'news'
      );
    } else {
      setOtpError(true);
    }
  };

  // Sign out triggers reset
  const handleSignout = () => {
    setUser(null);
    setVerificationMode(false);
    setCurrentThreadId(null);
  };

  // COMMUNITY FEED LOGIC
  const handlePublishPost = (content: string, category: 'General' | 'News' | 'Cultural' | 'Urgent') => {
    const newPostObj: FeedPost = {
      id: 'f_' + Date.now(),
      userId: user?.id || 'u_me',
      userName: user?.name || 'Anonymous Sudanese',
      userAvatar: user?.avatar || '🇸🇩',
      content,
      datetime: new Date().toISOString(),
      category,
      likes: 0,
      comments: [],
    };
    setFeedPosts((prev) => [newPostObj, ...prev]);
    triggerNotificationAlert(
      language === 'ar' ? 'تم نشر المنشور بالصالة!' : 'Successfully Published!',
      language === 'ar' ? 'منشورك متاح الآن لعائلتك وأصدقائك بجميع القارات.' : 'Your post is now active on global diaspora circles.',
      'news'
    );
  };

  const handleLikePost = (postId: string) => {
    setFeedPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          const liked = !post.likedByMe;
          return {
            ...post,
            likes: liked ? post.likes + 1 : post.likes - 1,
            likedByMe: liked,
          };
        }
        return post;
      })
    );
  };

  const handleAddComment = (postId: string, commentText: string) => {
    const newComment = {
      userName: user?.name || 'Yassir Al-Ameen',
      userAvatar: user?.avatar || '🇸🇩',
      text: commentText,
      datetime: new Date().toISOString(),
    };
    setFeedPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          return {
            ...post,
            comments: [...post.comments, newComment],
          };
        }
        return post;
      })
    );
  };

  // CAREERS LOGIC
  const handleAddJobPost = (newJob: Omit<JobPost, 'id' | 'datetime'>) => {
    const jobWithMetadata: JobPost = {
      ...newJob,
      id: 'j_' + Date.now(),
      datetime: new Date().toISOString(),
    };
    setJobPosts((prev) => [jobWithMetadata, ...prev]);
    triggerNotificationAlert(
      language === 'ar' ? 'تم نشر بطاقة التوظيف!' : 'Job Added!',
      language === 'ar' ? `تم إدراج وظيفة "${newJob.title}" في بوابة الأعمال.` : `Listed "${newJob.title}" job position successfully.`,
      'job'
    );
  };

  // MARKETPLACE SOUQ LOGIC
  const handleAddMarketplaceItem = (newItem: Omit<MarketplaceItem, 'id' | 'datetime'>) => {
    const marketplaceWithMetadata: MarketplaceItem = {
      ...newItem,
      id: 'm_' + Date.now(),
      datetime: new Date().toISOString(),
    };
    setMarketplaceItems((prev) => [marketplaceWithMetadata, ...prev]);
    triggerNotificationAlert(
      language === 'ar' ? 'تم إدراج سلعتك في السوق!' : 'Item Listed on Souq!',
      language === 'ar' ? `البضاعة "${newItem.title}" متاحة للشراء الآن.` : `Product "${newItem.title}" was published to Sudanese buyers.`,
      'marketplace'
    );
  };

  // Dynamic Marketplace contact bridges into Private Chats with automatic seller reply simulation
  const handleInitiateSellerChat = (item: MarketplaceItem) => {
    // If seller is me, prevent chatting with myself
    if (item.sellerId === 'u_me') {
      alert(language === 'ar' ? 'هذه سلعتك الخاصة المعروضة بالسوق!' : "This is your own listed item!");
      return;
    }

    // Identify if thread already exists
    let existingThread = chatThreads.find((t) => t.participantId === item.sellerId);
    let targetThreadId = existingThread?.id || '';

    if (!existingThread) {
      targetThreadId = 't_' + Date.now();
      const newThread: ChatThread = {
        id: targetThreadId,
        participantId: item.sellerId,
        participantName: item.sellerName,
        participantAvatar: '👤',
        lastMessage: language === 'ar' ? `استفسار عن سلعة: ${item.title}` : `Inquiry about item: ${item.title}`,
        timestamp: new Date().toISOString(),
        unreadCount: 0,
      };
      setChatThreads((prev) => [newThread, ...prev]);
    }

    // Prepend user message asking about item
    const greetingMsg = language === 'ar'
      ? `السلام عليكم، أنا مهتم بسلعتك "${item.title}" المعروضة بمبلغ ${item.price}. هل السلعة متوفرة؟`
      : `Salam, I am interested in your item "${item.title}" priced at ${item.price}. Is it still available?`;

    const userMsgObj: ChatMessage = {
      id: 'msg_' + Date.now(),
      senderId: 'me',
      receiverId: item.sellerId,
      text: greetingMsg,
      timestamp: new Date().toISOString(),
    };

    setChatMessages((prev) => [...prev, userMsgObj]);
    setCurrentThreadId(targetThreadId);
    setActiveTab('messaging');

    // Trigger instant Auto-responder from seller
    setTimeout(() => {
      const sellerReplyText = language === 'ar'
        ? `وعليكم السلام يا هلا مرحب بيك. نعم السلعة متوفرة وبحالة ممتازة فيصل معي بالواتساب على رقم هاتف: ${item.sellerPhone} لنتفق على التسليم واللقاء ومبارك للتسوق!`
        : `وعليكم السلام! Yes, the item "${item.title}" is indeed available. Let's arrange delivery. You can reach out on my WhatsApp: ${item.sellerPhone}. Thanks!`;

      const sellerMsgObj: ChatMessage = {
        id: 'msg_rep_' + Date.now(),
        senderId: item.sellerId,
        receiverId: 'me',
        text: sellerReplyText,
        timestamp: new Date().toISOString(),
      };

      setChatMessages((prev) => [...prev, sellerMsgObj]);
      
      // Update thread
      setChatThreads((prev) =>
        prev.map((t) => {
          if (t.id === targetThreadId) {
            return {
              ...t,
              lastMessage: sellerReplyText,
              timestamp: new Date().toISOString(),
            };
          }
          return t;
        })
      );

      triggerNotificationAlert(
        language === 'ar' ? `رسالة جديدة من بائع السوق` : 'New Message from Seller',
        `Reply from: ${item.sellerName}`,
        'chat'
      );
    }, 1500);
  };

  // EVENTS LOGIC
  const handleAddEvent = (newEvent: Omit<CommunityEvent, 'id' | 'rsvps'>) => {
    const eventWithMetadata: CommunityEvent = {
      ...newEvent,
      id: 'e_' + Date.now(),
      rsvps: 1,
      userRsvped: true,
    };
    setCommunityEvents((prev) => [eventWithMetadata, ...prev]);
    triggerNotificationAlert(
      language === 'ar' ? 'تم جدولة مناسبتكم العائلية!' : 'Event Organized!',
      language === 'ar' ? `المناسبة "${newEvent.title}" مدرجة بقسم الفعاليات.` : `Listed "${newEvent.title}" community gathering.`,
      'event'
    );
  };

  const handleRsvp = (eventId: string) => {
    setCommunityEvents((prev) =>
      prev.map((evt) => {
        if (evt.id === eventId) {
          const rsvped = !evt.userRsvped;
          return {
            ...evt,
            rsvps: rsvped ? evt.rsvps + 1 : evt.rsvps - 1,
            userRsvped: rsvped,
          };
        }
        return evt;
      })
    );
  };

  // PRIVATE MESSAGES LOGIC
  const handleSelectThread = (threadId: string) => {
    setCurrentThreadId(threadId);
    setChatThreads((prev) =>
      prev.map((th) => (th.id === threadId ? { ...th, unreadCount: 0 } : th))
    );
  };

  const handleSendMessage = (text: string) => {
    if (!currentThreadId) return;
    const activeThreadObj = chatThreads.find((t) => t.id === currentThreadId);
    if (!activeThreadObj) return;

    const userMsgObj: ChatMessage = {
      id: 'msg_' + Date.now(),
      senderId: 'me',
      receiverId: activeThreadObj.participantId,
      text,
      timestamp: new Date().toISOString(),
    };

    setChatMessages((prev) => [...prev, userMsgObj]);

    // Update thread meta
    setChatThreads((prev) =>
      prev.map((th) => {
        if (th.id === currentThreadId) {
          return {
            ...th,
            lastMessage: text,
            timestamp: new Date().toISOString(),
          };
        }
        return th;
      })
    );

    // Auto responder based on recipient
    const recipientId = activeThreadObj.participantId;
    setTimeout(() => {
      let automatedText = '';
      if (recipientId === 'u2') {
        // Ahmed
        automatedText = language === 'ar'
          ? 'بارك الله فيك يا ولد بلدي! سنلتقي في مركز وموقع المناسبات هذا السبت لنقوم بتحميل التبرعات العادلة والمحاسبة.'
          : 'Jazakallah Khair! We will meet near Hyde Park area this Saturday to coordinate youth contributions.';
      } else if (recipientId === 'u3') {
        // Mona
        automatedText = language === 'ar'
          ? 'أهلاً بك، نعم نحن نقوم بخدمة الفحوصات الطبية بشكل تطوعي كامل لأطفال السودان بالرياض، شرفنا غداً بالعيادة.'
          : 'Greetings! Our pediatric clinics are fully volunteer-based help lines for Sudanese families here in KSA.';
      } else {
        automatedText = language === 'ar'
          ? 'تواصلك يسعدني، سأوافيك بكل الردود والتفاصيل بالهاتف وبارك الله في جهود عائلتنا بدار المغتربين.'
          : 'Thank you for connecting with other Sudanese globally. We are together (Id Wahda).';
      }

      const responderMsgObj: ChatMessage = {
        id: 'msg_auto_' + Date.now(),
        senderId: recipientId,
        receiverId: 'me',
        text: automatedText,
        timestamp: new Date().toISOString(),
      };

      setChatMessages((prev) => [...prev, responderMsgObj]);

      setChatThreads((prev) =>
        prev.map((th) => {
          if (th.id === currentThreadId) {
            return {
              ...th,
              lastMessage: automatedText,
              timestamp: new Date().toISOString(),
            };
          }
          return th;
        })
      );

      triggerNotificationAlert(
        language === 'ar' ? `رسالة جديدة من ${activeThreadObj.participantName}` : `New chat from ${activeThreadObj.participantName}`,
        automatedText,
        'chat'
      );
    }, 1500);
  };

  // SERVICE REGISTRATION IN DIRECTORY
  const handleRegisterService = (e: React.FormEvent) => {
    e.preventDefault();
    if (!svcName || !svcAddress || !svcPhone || !svcDesc) return;

    // Create a randomized position coordinate within Riyadh & London maps grids (percentage boundaries)
    const randomLat = 25 + Math.floor(Math.random() * 40);
    const randomLng = 20 + Math.floor(Math.random() * 50);

    const newSvc: DirectoryService = {
      id: 's_' + Date.now(),
      name: svcName,
      category: svcCategory,
      rating: 5.0,
      address: svcAddress,
      phone: svcPhone,
      description: svcDesc,
      website: svcWebsite || undefined,
      lat: randomLat,
      lng: randomLng,
    };

    setDirectoryServices((prev) => [newSvc, ...prev]);
    setSelectedService(newSvc); // Focus on Map live

    // Reset
    setSvcName('');
    setSvcAddress('');
    setSvcPhone('');
    setSvcDesc('');
    setSvcWebsite('');
    setIsRegServiceOpen(false);

    triggerNotificationAlert(
      language === 'ar' ? 'تم تسجيل وبث خدمتك بالدليل!' : 'Service Registered Successfully!',
      language === 'ar' ? `تم تثبيت دبابيس "${svcName}" على خريطتنا السودانية الحية.` : `Pinned "${svcName}" details onto Google-simulated diaspora map.`,
      'news'
    );
  };

  // PROFILE AVATAR UPDATES
  const handleAvatarSelect = (avatarEmoji: string) => {
    if (!user) return;
    setUser({ ...user, avatar: avatarEmoji });
  };

  // Profile data values update
  const handleUpdateProfileData = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    triggerNotificationAlert(
      language === 'ar' ? 'تم تحديث بيانات ملفك بنجاح' : 'Profile Updated!',
      language === 'ar' ? 'تم مواءمة وحفظ تفاصيلك الرقمية بالجالية السودانية.' : 'Successfully saved modifications in Cloud Firestore.',
      'news'
    );
  };

  const isRtl = language === 'ar';
  const t = translations[language];

  return (
    <div
      dir={isRtl ? 'rtl' : 'ltr'}
      className={`min-h-screen pb-12 transition-all duration-300 ${
        darkMode ? 'bg-zinc-950 text-slate-100 dark' : 'bg-slate-50/70 text-slate-800'
      }`}
    >
      {/* Dynamic Simulated Notification Banner sliding overlay */}
      {notificationBanner && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[100] w-full max-w-sm px-4 animate-slide-down">
          <div className="bg-slate-900 border-b-4 border-sudan-gold text-white p-4 rounded-xl shadow-2xl flex items-start gap-3 relative overflow-hidden">
            <span className="text-xl">
              {notificationBanner.type === 'chat'
                ? '💬'
                : notificationBanner.type === 'job'
                ? '💼'
                : notificationBanner.type === 'marketplace'
                ? '🏺'
                : '🔔'}
            </span>
            <div className="flex-1 space-y-0.5">
              <h5 className="text-xs font-bold font-cairo text-sudan-gold">
                {notificationBanner.title}
              </h5>
              <p className="text-[11px] text-slate-200 line-clamp-2 leading-normal font-sans">
                {notificationBanner.body}
              </p>
            </div>
            <button
              onClick={() => setNotificationBanner(null)}
              className="text-slate-400 hover:text-white font-bold ml-1 cursor-pointer font-sans"
            >
              ×
            </button>
          </div>
        </div>
      )}

      {/* Main Container Header */}
      <header className="sticky top-0 z-40 bg-gradient-to-l from-emerald-800 via-emerald-900 to-teal-950 text-white select-none shadow-md border-b-2 border-sudan-gold">
        <div className="w-full max-w-7xl mx-auto px-4 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            {/* National emblem Sudanese Flag icon next to brand */}
            <span className="text-3xl animate-pulse">🇸🇩</span>
            <div>
              <span className="text-xs font-mono tracking-widest text-sudan-gold/90 uppercase block font-medium">
                {isRtl ? 'بوابة المهجر العالمية' : 'DIASPORA GLOBAL PORTAL'}
              </span>
              <h1 className="text-xl font-black font-cairo text-white tracking-tight flex items-center gap-1">
                {t.appName}
                <span className="text-sudan-gold text-sm font-light">DARNA</span>
              </h1>
            </div>
          </div>

          {/* Configuration utility buttons */}
          <div className="flex items-center gap-2">
            {/* Quick connection stats badge */}
            <div className="hidden lg:flex items-center gap-1.5 bg-emerald-950/60 border border-emerald-800 rounded-full px-3 py-1 text-xs">
              <span className="w-2 h-2 rounded-full bg-sudan-gold animate-pulse"></span>
              <span className="font-medium text-slate-205 text-[11px] font-mono">
                {isRtl ? 'مسجلين نشطين: 142,504' : 'Globally active: 142,504'}
              </span>
            </div>

            {/* Language Selection Toggle */}
            <button
              onClick={() => {
                setLanguage(language === 'en' ? 'ar' : 'en');
                triggerNotificationAlert(
                  language === 'ar' ? 'English Language Mode Enabled' : 'تم تفعيل اللغة العربية بالكامل',
                  language === 'ar' ? 'RTL layouts and English phrasing configured.' : 'دارنا تدعم صالة التكافل بالاتجاه العربي لسهولة الاستخدام.',
                  'news'
                );
              }}
              className="px-2.5 py-1.5 rounded-lg bg-emerald-950/60 border border-emerald-800 hover:bg-emerald-950 text-xs font-bold transition-all flex items-center gap-1 cursor-pointer focus:ring-1 focus:ring-sudan-gold/60"
            >
              <Globe className="w-4 h-4 text-sudan-gold" />
              <span>{language === 'ar' ? 'English 🇬🇧' : 'العربية 🇸🇩'}</span>
            </button>

            {/* Dark Mode Switcher */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 rounded-lg bg-emerald-950/60 border border-emerald-800 hover:bg-emerald-950 transition-all cursor-pointer"
            >
              {darkMode ? <Sun className="w-4 h-4 text-yellow-400" /> : <Moon className="w-4 h-4 text-emerald-300" />}
            </button>

            {/* Simulated Alerts Bell */}
            <div className="relative">
              <button
                onClick={() => setShowNotificationsDropdown(!showNotificationsDropdown)}
                className="p-2 rounded-lg bg-emerald-950/60 border border-emerald-800 hover:bg-emerald-950 transition-all relative cursor-pointer"
              >
                <Bell className="w-4 h-4" />
                {notifications.some((n) => !n.read) && (
                  <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-sudan-red rounded-full border-2 border-emerald-900 animate-pulse"></span>
                )}
              </button>

              {/* Notification drop List overlay */}
              {showNotificationsDropdown && (
                <div className={`absolute top-11 ${
                  isRtl ? 'left-0' : 'right-0'
                } w-72 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-800 rounded-xl shadow-2xl overflow-hidden z-50 p-2 text-slate-800 dark:text-slate-100 font-cairo`}>
                  <div className="flex justify-between items-center px-2 py-1.5 border-b border-slate-150 dark:border-zinc-900">
                    <span className="text-xs font-bold">{t.notifications.title}</span>
                    <button
                      onClick={() => {
                        setNotifications((p) => p.map((n) => ({ ...n, read: true })));
                        setShowNotificationsDropdown(false);
                      }}
                      className="text-[10px] text-sudan-green font-semibold hover:underline"
                    >
                      {isRtl ? 'تحديد كقروء' : 'Mark all read'}
                    </button>
                  </div>

                  <div className="max-h-60 overflow-y-auto mt-1 divide-y divide-slate-105 dark:divide-zinc-900">
                    {notifications.length === 0 ? (
                      <div className="p-4 text-xs text-center text-slate-400">{t.notifications.empty}</div>
                    ) : (
                      notifications.map((notif) => (
                        <div key={notif.id} className={`p-2.5 text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-zinc-90 w-full transition-all flex flex-col gap-0.5 ${notif.read ? 'opacity-85' : 'bg-emerald-50/15 font-semibold'}`}>
                          <div className="flex justify-between items-center">
                            <span className="text-[10.5px] font-bold text-slate-850 dark:text-slate-100">{notif.title}</span>
                            <span className="text-[8px] text-slate-400">
                              {new Date(notif.timestamp).toLocaleTimeString(language === 'ar' ? 'ar' : 'en', {
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          </div>
                          <p className="text-[10px] leading-relaxed text-slate-400 dark:text-slate-450">{notif.body}</p>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Manual simulator test alert trigger */}
                  <div className="bg-slate-50 dark:bg-zinc-900/60 p-2 rounded border border-slate-150 dark:border-zinc-900 mt-2 text-center">
                    <button
                      onClick={() => {
                        triggerNotificationAlert(
                          isRtl ? 'تنبيه: رحلات شحن سودانية جديدة!' : 'Alert: New Diaspora Cargo Line',
                          isRtl ? 'تمت إضافة مكتب شحن جديد من القاهرة إلى ود مدني في دليل الدرب.' : 'Weekly container registered in London to Port Sudan route.',
                          'marketplace'
                        );
                        setShowNotificationsDropdown(false);
                      }}
                      className="w-full text-[10px] bg-sudan-green text-white font-bold py-1 px-2 rounded hover:bg-emerald-800 transition"
                    >
                      💡 {t.notifications.triggerMock}
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Logout button */}
            {user && (
              <button
                onClick={handleSignout}
                className="hidden md:flex items-center gap-1 bg-red-650 hover:bg-red-700 bg-sudan-red text-white py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0"
              >
                <LogOut className="w-4 h-4" />
                <span>{t.auth.signOut}</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Workspace Frame */}
      <main className="w-full max-w-7xl mx-auto px-4 mt-6">
        {!user ? (
          /* Authentication Screen with integrated SMS Verification passcode simulations */
          <div className="max-w-md mx-auto bg-white dark:bg-zinc-950 rounded-2xl border border-slate-200 dark:border-zinc-850 shadow-2xl overflow-hidden animate-fade-in font-cairo">
            {/* Heritage Header visual card */}
            <div className="bg-gradient-to-r from-emerald-800 to-teal-900 text-white p-6 text-center select-none border-b-4 border-sudan-gold relative">
              <span className="text-3xl filter hover:scale-110 transition-transform">🇸🇩</span>
              <h2 className="text-xl font-bold font-cairo mt-2">{t.auth.title}</h2>
              <p className="text-xs text-emerald-200 mt-1 leading-relaxed">{t.auth.subtitle}</p>
            </div>

            <div className="p-6">
              {verificationMode ? (
                /* SMS OTP simulated modal form */
                <form onSubmit={handleVerifyOtp} className="space-y-4 animate-scale-up">
                  <div className="bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900 rounded-lg p-3 text-xs leading-relaxed space-y-1.5 text-emerald-900 dark:text-emerald-300">
                    <div className="font-bold flex items-center gap-1">
                      <Lock className="w-3.5 h-3.5 text-sudan-green" />
                      <span>{t.auth.verificationCode}</span>
                    </div>
                    <p className="opacity-90">{t.auth.otpMessage}</p>
                    <div className="font-mono text-center font-bold text-sm bg-white dark:bg-zinc-950 p-1.5 border border-emerald-500/20 rounded mt-1 text-emerald-600 animate-pulse">
                      Darna SMS: 482129
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-450 dark:text-slate-400 mb-1">
                      {t.auth.enterOtp}
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. 482129"
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value)}
                      maxLength={6}
                      className="w-full p-2.5 bg-slate-50 dark:bg-zinc-900 border border-slate-205 dark:border-zinc-800 text-slate-800 dark:text-slate-100 text-center text-sm font-mono tracking-[4px] rounded outline-none focus:border-sudan-green-500"
                    />
                  </div>

                  {otpError && (
                    <div className="p-2 bg-red-50 text-sudan-red border border-red-200 rounded text-[11px] flex items-center gap-1">
                      <AlertCircle className="w-4 h-4 flex-shrink-0" />
                      <span>{t.auth.incorrectOtp}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full bg-sudan-green hover:bg-emerald-800 text-white font-bold py-2.5 px-4 rounded-xl text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{t.auth.verifyBtn}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setVerificationMode(false);
                      setOtpCode('');
                    }}
                    className="w-full border border-slate-200 dark:border-zinc-800 text-slate-500 font-bold py-2 px-4 rounded text-xs hover:bg-slate-50 cursor-pointer"
                  >
                    {t.common.back}
                  </button>
                </form>
              ) : (
                /* Primary registration / Sign-in form */
                <form onSubmit={handleInitialAuth} className="space-y-4">
                  {isSignUP && (
                    <div className="space-y-3.5 transition-all">
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">{t.auth.fullName}</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Tarig Osman"
                          value={authName}
                          onChange={(e) => setAuthName(e.target.value)}
                          className="w-full p-2 bg-slate-50 dark:bg-zinc-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-zinc-800 rounded text-xs outline-none focus:border-sudan-green"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">{t.auth.phone}</label>
                        <input
                          type="text"
                          placeholder="e.g. +249 912... or +44..."
                          value={authPhone}
                          onChange={(e) => setAuthPhone(e.target.value)}
                          className="w-full p-2 bg-slate-50 dark:bg-zinc-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-zinc-800 rounded text-xs outline-none focus:border-sudan-green"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">{t.auth.city}</label>
                          <input
                            type="text"
                            placeholder="e.g. London"
                            value={authCity}
                            onChange={(e) => setAuthCity(e.target.value)}
                            className="w-full p-2 bg-slate-50 dark:bg-zinc-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-zinc-800 rounded text-xs outline-none focus:border-sudan-green"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">{t.auth.country}</label>
                          <input
                            type="text"
                            placeholder="e.g. United Kingdom"
                            value={authCountry}
                            onChange={(e) => setAuthCountry(e.target.value)}
                            className="w-full p-2 bg-slate-50 dark:bg-zinc-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-zinc-800 rounded text-xs outline-none focus:border-sudan-green"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">{t.auth.email}</label>
                    <input
                      type="email"
                      required
                      placeholder="careers@darna.org"
                      value={authEmail}
                      onChange={(e) => setAuthEmail(e.target.value)}
                      className="w-full p-2 bg-slate-50 dark:bg-zinc-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-zinc-800 rounded text-xs outline-none focus:border-sudan-green"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">{t.auth.password}</label>
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={authPassword}
                      onChange={(e) => setAuthPassword(e.target.value)}
                      className="w-full p-2 bg-slate-50 dark:bg-zinc-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-zinc-800 rounded text-xs outline-none focus:border-sudan-green"
                    />
                  </div>

                  {isSignUP && (
                    <label className="flex items-start gap-2 text-xs text-slate-500 leading-normal pl-1 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={sudaneseConfirmed}
                        onChange={(e) => setSudaneseConfirmed(e.target.checked)}
                        className="mt-0.5 rounded text-sudan-green focus:ring-0"
                      />
                      <span>{t.auth.sudaneseCheck}</span>
                    </label>
                  )}

                  <button
                    type="submit"
                    className="w-full bg-sudan-green hover:bg-emerald-800 text-white font-bold py-2.5 px-4 rounded-xl text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
                  >
                    <Lock className="w-3.5 h-3.5 text-sudan-gold" />
                    <span>{isSignUP ? t.auth.signUp : t.auth.signIn}</span>
                  </button>

                  {/* Switch toggler */}
                  <div className="text-center pt-2">
                    <button
                      type="button"
                      onClick={() => setIsSignUp(!isSignUP)}
                      className="text-xs text-sudan-green hover:underline font-semibold"
                    >
                      {isSignUP ? t.auth.haveAccount : t.auth.needAccount}
                    </button>
                  </div>

                  {/* Quick bypass divider line */}
                  <div className="relative flex py-2 items-center">
                    <div className="flex-grow border-t border-slate-200 dark:border-zinc-850"></div>
                    <span className="flex-shrink mx-4 text-slate-400 text-[10px] uppercase font-mono">FOR CRITICS & CONTEXT</span>
                    <div className="flex-grow border-t border-slate-200 dark:border-zinc-850"></div>
                  </div>

                  <button
                    type="button"
                    onClick={handleFastDemoLogin}
                    className="w-full border border-dashed border-sudan-gold bg-amber-500/5 hover:bg-amber-500/10 text-[#9E730B] font-bold py-2.5 px-4 rounded-xl text-xs transition-all flex items-center justify-center gap-1 cursor-pointer"
                  >
                    🇸🇩 {isRtl ? 'تسجيل دخول سريع لتقييم المنصة' : 'Fast Bypass Demo Account (Residing in UK)'}
                  </button>
                </form>
              )}
            </div>
          </div>
        ) : (
          /* Logged In Dashboard Frame with responsive grid system */
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start font-cairo">
            
            {/* Left sidebar widgets panels on large screens */}
            <div className="lg:col-span-1 space-y-4">
              
              {/* Profile Card summary */}
              <div className="bg-white dark:bg-zinc-950 p-4 rounded-xl border border-slate-200 dark:border-zinc-850 shadow-sm flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-emerald-50 dark:bg-zinc-900 border-2 border-sudan-gold shadow-inner flex items-center justify-center text-3xl select-none relative">
                  {user.avatar}
                  {/* Verified flag badge on avatar */}
                  <span className="absolute bottom-0 right-0 p-0.5 bg-sudan-green text-white rounded-full text-[9px] border border-white">
                    🇸🇩
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 mt-2 font-cairo">
                  {user.name}
                </h3>

                <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-0.5 font-mono">
                  <MapPin className="w-3.5 h-3.5 text-rose-500" />
                  {user.city}, {user.country}
                </p>

                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-3 border-t border-slate-100 dark:border-zinc-900 pt-2.5 leading-relaxed italic max-w-xs">
                  "{user.bio.slice(0, 95)}..."
                </p>

                {/* Diaspora active indicator tags */}
                <span className="bg-emerald-50 text-sudan-green text-[10px] font-bold px-2.5 py-0.5 rounded-full mt-3 dark:bg-emerald-950/20">
                  {isRtl ? 'عضوية سودانية موثقة 🇸🇩' : 'Verified Sudanese Native'}
                </span>
              </div>

              {/* Navigation Tab rail list */}
              <div className="bg-white dark:bg-zinc-950 rounded-xl border border-slate-201 border-slate-200 dark:border-zinc-850 p-2 flex flex-col gap-1 shadow-sm select-none">
                {[
                  { id: 'feed', emoji: '💬', title: t.tabs.feed, count: 0 },
                  { id: 'jobs', emoji: '💼', title: t.tabs.jobs, count: jobPosts.length },
                  { id: 'marketplace', emoji: '🏺', title: t.tabs.marketplace, count: marketplaceItems.length },
                  { id: 'services', emoji: '📍', title: t.tabs.services, count: directoryServices.length },
                  { id: 'events', emoji: '📅', title: t.tabs.events, count: communityEvents.length },
                  { id: 'messaging', emoji: '✉️', title: t.tabs.messaging, count: chatThreads.reduce((acc, t_item) => acc + t_item.unreadCount, 0) },
                  { id: 'profile', emoji: '👤', title: t.tabs.profile, count: 0 },
                  { id: 'devhub', emoji: '💻', title: isRtl ? 'كود المبرمجين (Flutter)' : 'Flutter Source Hub', count: 0, highlight: true },
                ].map((tb) => {
                  const isActive = activeTab === tb.id;
                  return (
                    <button
                      key={tb.id}
                      onClick={() => {
                        setActiveTab(tb.id as any);
                        setMenuOpen(false);
                      }}
                      className={`w-full p-2.5 rounded-lg flex items-center justify-between transition-all font-cairo text-xs font-semibold cursor-pointer text-left ${
                        isRtl ? 'text-right' : 'text-left'
                      } ${
                        isActive
                          ? tb.highlight
                            ? 'bg-gradient-to-r from-teal-900 to-emerald-800 text-white shadow-md border-b-2 border-sudan-gold'
                            : 'bg-emerald-50 text-sudan-green border-l-4 border-sudan-green dark:bg-zinc-900 dark:text-emerald-400 dark:border-sudan-green'
                          : 'text-slate-650 hover:bg-slate-50 dark:text-slate-350 dark:hover:bg-zinc-900/60'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-base">{tb.emoji}</span>
                        <span>{tb.title}</span>
                      </div>
                      {tb.count > 0 && (
                        <span className="text-[10px] bg-red-100 text-sudan-red dark:bg-red-950/40 dark:text-red-400 font-bold px-1.5 py-0.5 rounded-full font-mono">
                          {tb.count}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Mobile logout and helper layout controls */}
              <button
                onClick={handleSignout}
                className="w-full bg-red-50 hover:bg-red-100 text-sudan-red font-bold p-2.5 rounded-xl text-xs transition-all flex items-center justify-center gap-1 border border-red-200 cursor-pointer lg:hidden"
              >
                <LogOut className="w-4 h-4" />
                <span>{t.auth.signOut}</span>
              </button>
            </div>

            {/* Right main subview content workspace depending on active tab state */}
            <div className="lg:col-span-3 space-y-4">
              
              {/* ACTIVE SUBVIEWS AND ROUTERS CONTAINER */}
              {activeTab === 'feed' && (
                <FeedSection
                  feedPosts={feedPosts}
                  currentUserAvatar={user.avatar}
                  currentUserName={user.name}
                  onLikePost={handleLikePost}
                  onAddComment={handleAddComment}
                  onPublishPost={handlePublishPost}
                  language={language}
                />
              )}

              {activeTab === 'jobs' && (
                <CareersSection
                  jobPosts={jobPosts}
                  onAddJobPost={handleAddJobPost}
                  language={language}
                />
              )}

              {activeTab === 'marketplace' && (
                <SouqSection
                  marketplaceItems={marketplaceItems}
                  onAddMarketplaceItem={handleAddMarketplaceItem}
                  onInitiateSellerChat={handleInitiateSellerChat}
                  language={language}
                />
              )}

              {activeTab === 'services' && (
                <div className="space-y-6 animate-fade-in font-cairo">
                  {/* Service directory header */}
                  <div className="flex flex-col md:flex-row gap-4 items-center justify-between border-b border-slate-100 dark:border-zinc-900 pb-3">
                    <div>
                      <h3 className="text-base font-bold text-slate-850 dark:text-slate-100">
                        {t.directory.title}
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-405">
                        {t.directory.subtitle}
                      </p>
                    </div>

                    <button
                      onClick={() => setIsRegServiceOpen(!isRegServiceOpen)}
                      className="bg-sudan-green hover:bg-emerald-800 text-white font-bold text-xs px-4 py-2 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer shadow-sm shrink-0"
                    >
                      <Building className="w-4 h-4" />
                      <span>{isRegServiceOpen ? (isRtl ? 'إغلاق التسجيل' : 'Close Register Form') : t.directory.registerBusiness}</span>
                    </button>
                  </div>

                  {/* Register Service Form collapse */}
                  {isRegServiceOpen && (
                    <form onSubmit={handleRegisterService} className="bg-slate-50 dark:bg-zinc-900/60 p-5 rounded-xl border border-slate-200 dark:border-zinc-805 animate-slide-down space-y-4">
                      <div className="flex justify-between items-center border-b border-slate-150 dark:border-zinc-800 pb-1.5">
                        <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                          {isRtl ? 'سجل وكالتك أو دكانك في دليل شبكة الجالية السودانية' : 'Register Your Business in Diaspora Directory'}
                        </h4>
                        <span className="text-[10px] bg-sudan-green text-white font-mono px-2 py-0.5 rounded font-bold">DIRECTORY PIN</span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">{isRtl ? 'اسم المرفق / الخدمة التجارية' : 'Business Name'}</label>
                          <input
                            type="text"
                            required
                            placeholder={isRtl ? 'مثال: مطعم مروي للأكلات، الدكتور أحمد لطب الأسنان' : 'e.g. Al-Nile Halal Grocery'}
                            value={svcName}
                            onChange={(e) => setSvcName(e.target.value)}
                            className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-850 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">{isRtl ? 'رقم الهاتف للتواصل بالدليل' : 'Business WhatsApp / Phone'}</label>
                          <input
                            type="text"
                            required
                            placeholder="+249 / +966 / +44"
                            value={svcPhone}
                            onChange={(e) => setSvcPhone(e.target.value)}
                            className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-850 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">{isRtl ? 'تصنيف المرفق بالدليل' : 'Business Category'}</label>
                          <select
                            value={svcCategory}
                            onChange={(e) => setSvcCategory(e.target.value as any)}
                            className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-850 text-slate-705 dark:text-slate-300 rounded text-xs outline-none focus:border-sudan-green"
                          >
                            <option value="Restaurant">🛋️ {isRtl ? 'مطعم ومقهى وعائلات' : 'Dining & Café'}</option>
                            <option value="Doctor">🩺 {isRtl ? 'طبيب ورعاية صحية' : 'Doctor & Clinics'}</option>
                            <option value="Lawyer">⚖️ {isRtl ? 'محاماة وشؤون هجرة' : 'Lawyer & Immigration'}</option>
                            <option value="Advisor">👔 {isRtl ? 'مستشار وخدمات جالية' : 'Community Advisory'}</option>
                            <option value="Shipping">🚢 {isRtl ? 'شحن البضائع والترسيم' : 'Shipping & Cargo'}</option>
                            <option value="Grocer">🛒 {isRtl ? 'بقالة حلال وتجهيزات' : 'Halal Grocer'}</option>
                            <option value="Cultural">🏛️ {isRtl ? 'ملتقى أو مركز ثقافي سوداني' : 'Cultural Center'}</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">{isRtl ? 'عنوان المرفق الجغرافي كامل' : 'Full Physical Address'}</label>
                          <input
                            type="text"
                            required
                            placeholder={isRtl ? 'مثال: شارع فيصل، القاهرة الكبرى' : 'e.g. Edgware Road, London'}
                            value={svcAddress}
                            onChange={(e) => setSvcAddress(e.target.value)}
                            className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-850 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">{isRtl ? 'موقع الإنترنت (اختياري)' : 'Website URL (Optional)'}</label>
                          <input
                            type="text"
                            placeholder="https://mysite.com"
                            value={svcWebsite}
                            onChange={(e) => setSvcWebsite(e.target.value)}
                            className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-850 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-500 mb-1">{isRtl ? 'نبذة مختصرة ومواعيد الدوام بالملف' : 'Brief Details & Hours'}</label>
                          <textarea
                            required
                            rows={1.5}
                            placeholder={isRtl ? 'مثال: نقدم أشهى الوجبات والمشروبات السودانية من 9 صباحاً...' : 'Describe opening hours, specialties, discount structures...'}
                            value={svcDesc}
                            onChange={(e) => setSvcDesc(e.target.value)}
                            className="w-full p-2 bg-white dark:bg-zinc-950 border border-slate-200 dark:border-zinc-850 text-slate-800 dark:text-zinc-200 rounded text-xs outline-none focus:border-sudan-green leading-relaxed"
                          />
                        </div>
                      </div>

                      <div className="flex justify-end gap-2.5 pt-1">
                        <button
                          type="button"
                          onClick={() => setIsRegServiceOpen(false)}
                          className="px-4 py-2 border border-slate-200 dark:border-zinc-800 text-slate-500 rounded text-xs font-semibold cursor-pointer"
                        >
                          {isRtl ? 'تراجع' : 'Close'}
                        </button>
                        <button
                          type="submit"
                          className="px-5 py-2 bg-sudan-green hover:bg-emerald-800 text-white rounded text-xs font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <span>{isRtl ? 'أكد التسجيل بالدليل والخرائط' : 'Register Service'}</span>
                        </button>
                      </div>
                    </form>
                  )}

                  {/* Interactive Pin-Map Simulator for Sudanese Businesses */}
                  <InteractiveMap
                    services={directoryServices}
                    selectedService={selectedService}
                    onSelectService={(svc) => setSelectedService(svc)}
                    language={language}
                  />

                  {/* Non-map directory collection lists */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {directoryServices.map((svc) => (
                      <div
                        key={svc.id}
                        onClick={() => setSelectedService(svc)}
                        className={`p-4 bg-white dark:bg-zinc-950 rounded-xl border transition-all cursor-pointer ${
                          selectedService?.id === svc.id
                            ? 'border-sudan-green ring-1 ring-sudan-green/[0.15] shadow-md bg-emerald-50/5'
                            : 'border-slate-200 hover:border-slate-350 dark:border-zinc-855'
                        }`}
                      >
                        <span className="text-[10px] bgs-emerald-50 bg-emerald-100 dark:bg-emerald-950/20 text-sudan-green px-2 py-0.5 rounded font-mono font-bold">
                          {svc.category}
                        </span>
                        <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 mt-1.5 font-cairo">
                          {svc.name}
                        </h4>
                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 pl-1 line-clamp-2 leading-relaxed">
                          {svc.description}
                        </p>
                        <div className="flex justify-between items-center text-[10.5px] mt-4 pt-2.5 border-t border-slate-100 dark:border-zinc-90 w-full text-slate-450 dark:text-slate-500 font-sans">
                          <div>📞 {svc.phone}</div>
                          <div className="text-[11px] text-amber-500">★ {svc.rating}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'events' && (
                <EventsSection
                  events={communityEvents}
                  onRsvp={handleRsvp}
                  onAddEvent={handleAddEvent}
                  language={language}
                />
              )}

              {activeTab === 'messaging' && (
                <MessagingSection
                  threads={chatThreads}
                  messages={chatMessages}
                  currentThreadId={currentThreadId}
                  onSelectThread={handleSelectThread}
                  onSendMessage={handleSendMessage}
                  language={language}
                />
              )}

              {activeTab === 'profile' && (
                <div className="bg-white dark:bg-zinc-950 rounded-xl border border-slate-200 dark:border-zinc-850 p-6 animate-fade-in font-cairo space-y-6">
                  <div>
                    <h3 className="text-base font-bold text-slate-850 dark:text-slate-100 font-cairo">
                      {t.profile.title}
                    </h3>
                    <p className="text-xs text-slate-450 dark:text-slate-405 mt-1">
                      {t.profile.subtitle}
                    </p>
                  </div>

                  {/* Stats numbers banner */}
                  <div className="grid grid-cols-3 gap-4 border-y border-slate-100 dark:border-zinc-900 py-4 text-center select-none">
                    <div className="space-y-0.5">
                      <span className="text-xl font-bold font-mono text-sudan-green">
                        {feedPosts.filter((p) => p.userId === user.id).length}
                      </span>
                      <p className="text-[10px] text-slate-405 dark:text-slate-450 font-semibold">{t.profile.posts}</p>
                    </div>
                    <div className="space-y-0.5">
                      <span className="text-xl font-bold font-mono text-sudan-green">
                        {marketplaceItems.filter((m) => m.sellerId === 'u_me').length}
                      </span>
                      <p className="text-[10px] text-slate-405 dark:text-slate-450 font-semibold">{t.profile.listings}</p>
                    </div>
                    <div className="space-y-0.5">
                      <span className="text-xl font-bold font-mono text-sudan-green">
                        {communityEvents.filter((e) => e.userRsvped).length}
                      </span>
                      <p className="text-[10px] text-slate-405 dark:text-slate-450 font-semibold">{t.profile.eventsCount}</p>
                    </div>
                  </div>

                  {/* Character Avatar Picker selector */}
                  <div className="space-y-3">
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">
                      {t.profile.customAvatar}
                    </label>
                    <div className="flex gap-2 flex-wrap pb-1 border-b border-dashed border-slate-150 dark:border-zinc-900">
                      {['🇸🇩', '👨', '👩', '👨‍💻', '👩‍⚕️', '🎙️', '👨‍💼', '👩‍💼', '💡', '🦁'].map((emoji) => {
                        const isSelectedAvatar = user.avatar === emoji;
                        return (
                          <button
                            key={emoji}
                            onClick={() => handleAvatarSelect(emoji)}
                            className={`w-11 h-11 rounded-lg text-2xl flex items-center justify-center transition-all cursor-pointer ${
                              isSelectedAvatar
                                ? 'bg-emerald-100 ring-2 ring-sudan-green scale-110 dark:bg-zinc-900'
                                : 'bg-slate-50 hover:bg-slate-100 dark:bg-zinc-950 border border-slate-150'
                            }`}
                          >
                            {emoji}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <form onSubmit={handleUpdateProfileData} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-500 mb-1">{t.auth.fullName}</label>
                      <input
                        type="text"
                        required
                        value={user.name}
                        onChange={(e) => setUser({ ...user, name: e.target.value })}
                        className="w-full p-2 bg-slate-50 dark:bg-zinc-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-zinc-800 rounded text-xs outline-none focus:border-sudan-green"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-500 mb-1">{t.profile.phone}</label>
                      <input
                        type="text"
                        required
                        value={user.phone}
                        onChange={(e) => setUser({ ...user, phone: e.target.value })}
                        className="w-full p-2 bg-slate-50 dark:bg-zinc-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-zinc-800 rounded text-xs outline-none focus:border-sudan-green"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">{t.auth.city}</label>
                        <input
                          type="text"
                          required
                          value={user.city}
                          onChange={(e) => setUser({ ...user, city: e.target.value })}
                          className="w-full p-2 bg-slate-50 dark:bg-zinc-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-zinc-805 rounded text-xs outline-none focus:border-sudan-green"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">{t.auth.country}</label>
                        <input
                          type="text"
                          required
                          value={user.country}
                          onChange={(e) => setUser({ ...user, country: e.target.value })}
                          className="w-full p-2 bg-slate-50 dark:bg-zinc-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-zinc-805 rounded text-xs outline-none focus:border-sudan-green"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-500 mb-1">{t.profile.bio}</label>
                      <textarea
                        required
                        rows={2}
                        value={user.bio}
                        onChange={(e) => setUser({ ...user, bio: e.target.value })}
                        className="w-full p-2 bg-slate-50 dark:bg-zinc-900 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-zinc-805 rounded text-xs outline-none focus:border-sudan-green leading-relaxed"
                      />
                    </div>

                    <div className="col-span-1 md:col-span-2 pt-2">
                      <button
                        type="submit"
                        className="bg-sudan-green hover:bg-emerald-800 text-white font-bold text-xs py-2 px-6 rounded-lg transition-all cursor-pointer shadow flex items-center justify-center gap-1.5"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>{t.profile.updateBtn}</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {activeTab === 'devhub' && (
                <DeveloperHub language={language} />
              )}

            </div>

          </div>
        )}
      </main>
    </div>
  );
}
