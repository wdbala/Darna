/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { FeedPost, JobPost, MarketplaceItem, DirectoryService, CommunityEvent, ChatThread } from './types';

export const initialFeedPosts: FeedPost[] = [
  {
    id: 'f1',
    userId: 'u2',
    userName: 'Ahmed Al-Sharif',
    userAvatar: '👨‍💼',
    content: 'Assalamu Alaikum family, we are conducting a charity drive this Saturday to support newly arriving Sudanese students with housing furniture and laptops. If you have spare items in London or Cairo, please let us know in the comments or RSVP to the charity event!',
    datetime: '2026-05-29T10:30:00Z',
    category: 'Urgent',
    likes: 24,
    likedByMe: false,
    comments: [
      {
        userName: 'Mona Osman',
        userAvatar: '👩‍⚕️',
        text: 'Alhamdulillah, I have a working Dell laptop and a study desk to contribute. Can you arrange a pickup near Ealing?',
        datetime: '2026-05-29T10:45:00Z',
      },
      {
        userName: 'Tarig Babiker',
        userAvatar: '👨‍💻',
        text: 'Excellent initiative. I can help with transportation and logistics in London.',
        datetime: '2026-05-29T11:00:00Z',
      }
    ],
  },
  {
    id: 'f2',
    userId: 'u3',
    userName: 'Mona Osman',
    userAvatar: '👩‍⚕️',
    content: 'Just a reminder for Sudanese families in Riyadh: The free health check-up clinic at Al-Mustaqbal center is running tomorrow afternoon. Please bring your kids for routine vaccine checks, there are several Sudanese doctors volunteering.',
    datetime: '2026-05-28T16:20:00Z',
    category: 'News',
    likes: 18,
    likedByMe: true,
    comments: [
      {
        userName: 'Fatima El-Nour',
        userAvatar: '👩',
        text: 'Jazakum Allah Khair, Dr. Mona! Is active registration required or can we do walk-ins?',
        datetime: '2026-05-28T17:15:00Z',
      }
    ]
  },
  {
    id: 'f3',
    userId: 'u4',
    userName: 'Omer Al-Amin',
    userAvatar: '🎙️',
    content: 'Excited to host a traditional Sudanese lute (Oud) evening with standard haqiba music next Friday. It is going to be in Cairo (Mohandessin) and also streamed live for families in North America and Europe. Let us keep our cultural ties high!',
    datetime: '2026-05-27T09:00:00Z',
    category: 'Cultural',
    likes: 42,
    likedByMe: false,
    comments: [],
  }
];

export const initialJobPosts: JobPost[] = [
  {
    id: 'j1',
    title: 'Senior Arabic Translator / Content Editor',
    company: 'Doha Global Media Hub',
    location: 'Doha, Qatar (Hybrid)',
    salary: '$4,000 - $5,500 / month',
    type: 'Full-time',
    description: 'Looking for a skilled content writer fluent in Arabic (Sudanese/Gulf dialects) and English. Responsible for editing press releases, managing cultural communications, and preparing transcripts.',
    contactEmail: 'careers@globalthreads.qa',
    contactPhone: '+974 5542 3321',
    datetime: '2026-05-28T08:00:00Z',
  },
  {
    id: 'j2',
    title: 'Bilingual Civil/Construction Site Engineer',
    company: 'Al-Bayan Engineering Group',
    location: 'Riyadh, Saudi Arabia',
    salary: '12,000 - 15,000 SAR / month',
    type: 'Full-time',
    description: 'Seeking a civil engineer with 4+ years of site supervision experience. Candidates who graduated from University of Khartoum or Sudan University of Science & Technology are highly welcomed due to existing team composition.',
    contactEmail: 'hiring@albayan.sa',
    contactPhone: '+966 501 229 384',
    datetime: '2026-05-27T11:45:00Z',
  },
  {
    id: 'j3',
    title: 'Frontend Web Developer (React / Flutter)',
    company: 'SudanTech Diaspora Ventures',
    location: 'Remote (Global)',
    salary: '$30 - $45 / hour',
    type: 'Remote',
    description: 'Support our volunteer efforts and products by writing robust code. This is a freelance contract for 6 months to implement beautiful mobile interfaces for community tools.',
    contactEmail: 'apply@sudantech.org',
    contactPhone: '+44 7911 829103',
    datetime: '2026-05-26T14:30:00Z',
  }
];

export const initialMarketplaceItems: MarketplaceItem[] = [
  {
    id: 'm1',
    title: 'Elegant Sudanese Silk Thobe (Argo Pattern)',
    price: '$120',
    category: 'Clothing',
    location: 'Dubai, UAE',
    condition: 'Brand New',
    description: 'Beautiful traditional silk thobe imported directly from Omdurman. Golden borders with rich Argo patterns. Perfect for upcoming Eid and family weddings.',
    sellerId: 'u5',
    sellerName: 'Amal Osman',
    sellerPhone: '+971 52 334 1120',
    datetime: '2026-05-29T08:15:00Z',
  },
  {
    id: 'm2',
    title: 'Traditional Sudanese Bakhoor (Asal & Sandalwood)',
    price: '$45',
    category: 'Traditional',
    location: 'Dallas, TX, USA',
    condition: 'Brand New',
    description: 'Premium home incense, handmade by order using original Sudanese sandalwood oil (Sandal Al-Karon), sugar syrups, and heritage spices. Gives a long-lasting exquisite home scent.',
    sellerId: 'u6',
    sellerName: 'Hajja Aisha Siddig',
    sellerPhone: '+1 469 334 0929',
    datetime: '2026-05-28T12:00:00Z',
  },
  {
    id: 'm3',
    title: 'Double Traditional Clay Coffee Pot (Jebena) + Base',
    price: '$35',
    category: 'Traditional',
    location: 'London, UK',
    condition: 'Like New',
    description: 'Original clay Jebena pot with dynamic hand carvings and straw base ring. Brings the genuine incense-smoked Sudanese coffee (Gahwa) aroma back into your UK kitchen.',
    sellerId: 'u7',
    sellerName: 'Osman Abdelgadir',
    sellerPhone: '+44 7722 094112',
    datetime: '2026-05-28T09:30:00Z',
  },
  {
    id: 'm4',
    title: 'Samsung Galaxy S23 Ultra - Gold Edition',
    price: '$650',
    category: 'Electronics',
    location: 'Cairo, Egypt',
    condition: 'Good',
    description: 'Fully unlocked phone, active for all networks worldwide. Clean screens and optimal battery health. Selling because of upgrade. Cash upon meetup in Mohandessin.',
    sellerId: 'u8',
    sellerName: 'Waleed El-Mubarak',
    sellerPhone: '+20 112 344 0928',
    datetime: '2026-05-25T15:10:00Z',
  }
];

export const initialDirectoryServices: DirectoryService[] = [
  {
    id: 's1',
    name: 'Al-Kandaka Traditional Kitchen',
    category: 'Restaurant',
    rating: 4.9,
    address: 'Edgware Rd, London W2 2EA, UK',
    phone: '+44 207 433 9284',
    email: 'alkandaka.london@gmail.com',
    website: 'https://alkandakakitchen.co.uk',
    description: 'Authentic Sudanese mainstays in the heart of London! Serving fresh kisra, gurasa, mullah, lamb agashe, and sweet Hibiscus karkadeh juice. Clean family seating area.',
    lat: 42, // Map Y percent
    lng: 48, // Map X percent
  },
  {
    id: 's2',
    name: 'Nile Diaspora Immigration Attorneys',
    category: 'Lawyer',
    rating: 4.8,
    address: '14th St NW, Washington, DC 20005, USA',
    phone: '+1 202 555 9211',
    email: 'advisors@nileimmigration.com',
    website: 'https://nileimmigration.com',
    description: 'Specialized legal advisors and attorneys helping Sudanese with asylum processes, professional green-card sponsorships, family visas, and TPS applications.',
    lat: 38,
    lng: 28,
  },
  {
    id: 's3',
    name: 'Dr. Tariq Salih - Family Consultant & Pediatrician',
    category: 'Doctor',
    rating: 4.9,
    address: 'Olaya District, Riyadh 12211, Saudi Arabia',
    phone: '+966 11 405 9328',
    email: 't.salih@diaspora-med.sa',
    description: 'Expert consultant answering family issues with complete empathy. Offers consultations in Arabic, English, and Sudanese cultural frameworks. Over 20 years of practice.',
    lat: 56,
    lng: 62,
  },
  {
    id: 's4',
    name: 'El-Merreikh Quick Cargo & Money Transfer',
    category: 'Shipping',
    rating: 4.7,
    address: 'Faisal Street, Cairo, Egypt',
    phone: '+20 102 334 9821',
    website: 'https://elmerreikh-cargo.com',
    description: 'Weekly cargo containers shipping household goods, laptops, medicines, and packages from Cairo to Omdurman, Khartoum, Wad Madani and Port Sudan. Best rates in Cairo.',
    lat: 48,
    lng: 55,
  }
];

export const initialCommunityEvents: CommunityEvent[] = [
  {
    id: 'e1',
    title: 'Annual Sudanese Diaspora Summer Festival',
    organizer: 'UK Sudanese Association & Friends',
    datetime: '2026-06-15T11:00:00Z',
    location: 'Hyde Park Picnic Area, London, UK',
    category: 'Social',
    rsvps: 184,
    userRsvped: false,
    description: 'Annual gathering featuring national musical ensembles, youth agashe BBQ, book booths, and fun interactive activities for kids. Bring your flags and national spirit!',
  },
  {
    id: 'e2',
    title: 'Emergency Webinar: Support for Regional Hospitals',
    organizer: 'Sudanese Medical Association Worldwide',
    datetime: '2026-06-02T19:00:00Z',
    location: 'Zoom Video Conference Link',
    category: 'Virtual',
    rsvps: 96,
    userRsvped: true,
    description: 'Discussing remote telemedicine configurations, regional aid supply chains, and training modules. Featuring expert lectures from doctors across Gulf and North America.',
  },
  {
    id: 'e3',
    title: 'Traditional Henna & Bridal Heritage Showcase',
    organizer: 'Sudanese Women Cultural Center',
    datetime: '2026-06-20T16:00:00Z',
    location: 'Sharjah Heritage Area, Sharjah, UAE',
    category: 'Cultural',
    rsvps: 74,
    userRsvped: false,
    description: 'An interactive exhibition demonstrating classical Sudanese wedding styles, traditional incense formulations (Dilka), and beautiful regional henna arts.',
  }
];

export const initialChatThreads: ChatThread[] = [
  {
    id: 't1',
    participantId: 'u2',
    participantName: 'Ahmed Al-Sharif',
    participantAvatar: '👨‍💼',
    lastMessage: 'Awesome, we will count on your laptop donation. Thank you!',
    timestamp: '2026-05-29T11:05:00Z',
    unreadCount: 1,
  },
  {
    id: 't2',
    participantId: 'u3',
    participantName: 'Mona Osman',
    participantAvatar: '👩‍⚕️',
    lastMessage: 'The Riyadh clinic will have active signs in Arabic.',
    timestamp: '2026-05-28T18:00:00Z',
    unreadCount: 0,
  },
  {
    id: 't5',
    participantId: 'u5',
    participantName: 'Amal Osman (Thobe Seller)',
    participantAvatar: '👩‍💼',
    lastMessage: 'Hello brother, yes the Argo pattern is still available in red.',
    timestamp: '2026-05-29T09:12:00Z',
    unreadCount: 0,
  }
];
