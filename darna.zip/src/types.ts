/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  bio: string;
  city: string;
  country: string;
  phone: string;
}

export interface Comment {
  userName: string;
  userAvatar: string;
  text: string;
  datetime: string;
}

export interface FeedPost {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  datetime: string;
  category: 'General' | 'News' | 'Cultural' | 'Urgent';
  likes: number;
  likedByMe?: boolean;
  comments: Comment[];
}

export interface JobPost {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  type: 'Full-time' | 'Part-time' | 'Remote' | 'Contract';
  description: string;
  contactEmail: string;
  contactPhone: string;
  datetime: string;
}

export interface MarketplaceItem {
  id: string;
  title: string;
  price: string;
  category: 'Furniture' | 'Clothing' | 'Electronics' | 'Traditional' | 'Other';
  location: string;
  condition: 'Brand New' | 'Like New' | 'Good' | 'Fair';
  description: string;
  sellerId: string;
  sellerName: string;
  sellerPhone: string;
  datetime: string;
}

export interface DirectoryService {
  id: string;
  name: string;
  category: 'Restaurant' | 'Doctor' | 'Lawyer' | 'Advisor' | 'Shipping' | 'Grocer' | 'Cultural';
  rating: number;
  address: string;
  phone: string;
  email?: string;
  website?: string;
  description: string;
  lat: number; // For simulator map mapping (-100 to 100 percentages or custom coords)
  lng: number;
}

export interface CommunityEvent {
  id: string;
  title: string;
  organizer: string;
  datetime: string;
  location: string;
  category: 'Religious' | 'Cultural' | 'Charity' | 'Social' | 'Virtual';
  rsvps: number;
  userRsvped?: boolean;
  description: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  receiverId: string;
  text: string;
  timestamp: string;
}

export interface ChatThread {
  id: string;
  participantId: string;
  participantName: string;
  participantAvatar: string;
  lastMessage: string;
  timestamp: string;
  unreadCount: number;
}

export interface AppNotification {
  id: string;
  title: string;
  body: string;
  timestamp: string;
  read: boolean;
  type: 'news' | 'chat' | 'marketplace' | 'job' | 'event';
}
